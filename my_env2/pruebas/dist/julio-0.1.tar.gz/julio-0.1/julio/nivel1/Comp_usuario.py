from julio.usuarios import Usuario
u = usuarioj.usuario()
n = input("Contraseña: ")
print(u.test_passwd(n))
