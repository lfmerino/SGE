from setuptools import setup
setup(
    name="julio",
    version="0.1",
    description="Este es un paquete de ejemplo",
    author="Luis Merino",
    author_email="luisfrancisco.merino@edu.jccm.esm",
    url="briandademendoza.es",
    packages=['julio','julio.nivel1'],
    scripts=[]
)
