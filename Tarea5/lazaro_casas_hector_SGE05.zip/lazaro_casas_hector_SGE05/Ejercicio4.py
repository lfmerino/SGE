#!/usr/bin/python3

import os
from prettytable import PrettyTable
from prettytable import from_csv
from pathlib import Path
import csv
import Ejercicio3
import re

#pip install prettytable

class Tablas:
    
    def __init__(self):
        self.i = 0
        self.header_table = ["Nombre","Apellidos","Fecha","Direccion","Contraseña"]
        self.tabla_dic = PrettyTable()
        self.tabla_dic.field_names = self.header_table
        
    def iniciar_menu(self):
        
        print("1. Introducir datos")
        print("2. Buscar por nombre")
        print("3. Buscar por apellido")
        print("4. Volcar tabla de datos a fichero CSV")
        print("5. Rellenar tabla desde CSV")
        print("0. Salir")

    def iniciar_datos(self):
    
        respuesta = 1
        while respuesta >= 0 and respuesta < 6:

            self.iniciar_menu()
            try:
                respuesta = int(input("Elija una opción del menú: "))
            except:
                print("\nError: Debes escribir un número del 0 al 5\n")
                respuesta = -1
                
            if respuesta == 1:
                    self.introducir_datos()
            if respuesta == 2:
                self.buscar_nombre()
            if respuesta == 3:
                self.buscar_apellido()
            if respuesta == 4:
                self.crear_csv("usuarios.csv",self.tabla_dic,self.header_table)
            if respuesta == 5:
                self.llenar_tabla("usuarios.csv",self.tabla_dic)
            if respuesta == 0:
                exit()
            if respuesta < 0 or respuesta > 5:
                print("\nError: Debes escribir un número del 0 al 5\n")
                respuesta = 0

    def introducir_datos(self):

        nombre = Ejercicio3.pedir_usuario()
        password = Ejercicio3.pedir_password()
        apellido = input("Introduce apellidos: ")
        fecha = input("Introduce fecha de nacimiento [dd-mm-yyyy]: ")
        direccion = input("Introduce dirección: ")

        dic = {'nombre':nombre,'apellido':apellido,'fecha':fecha,'direccion':direccion,'password':password}
        self.tabla_dic.add_row(dic.values())
        #print(self.tabla_dic)

        

    def buscar_nombre(self):
        nombre = input("Introduce nombre de usuario a buscar: ")
        for row in self.tabla_dic:
            row.border = False
            row.header = False
            user = row.get_string(fields = ["Nombre"]).strip()
            if(user == nombre):
                print(row)

    def buscar_apellido(self):
        apellido = input("Introduce el apellido a buscar: ")
        for row in self.tabla_dic:
            row.border = False
            row.header = False
            user = row.get_string(fields = ["Apellidos"]).strip()
            if(user == apellido):
                print(row)

    def crear_csv(self, archivo_csv,tabla,header):
        #file_path = "D:\ELEARNING/2_DAM/MAYO/SGE/TEMA 5/TAREA 5/usuarios.csv"
        cabecera = str(header).replace('[', '').replace(']', '').replace("'", '"').replace(", ", ";")
        with open(archivo_csv, "w") as fp:
            fp.write(cabecera + "\n")
            for row in tabla:
                row.border = False
                row.header = False
                #print(row)
                fp.write('"' + str(row).replace("  ", '";"').strip() + '"' + "\n")
        

    def llenar_tabla(self,archivo_csv,tabla):
        #file_path = "D:\ELEARNING/2_DAM/MAYO/SGE/TEMA 5/TAREA 5/usuarios.csv"
        file = Path(archivo_csv)
        if (file.exists() == True):
            with open(archivo_csv, "r") as fp: 
                tabla = from_csv(fp)
                print(tabla)
        else:
            print("\nNo se encuentra el archivo usuarios.csv\n")
            
        return tabla

if __name__ == "__main__":
    mi_tabla = Tablas()
    mi_tabla.iniciar_datos()

            