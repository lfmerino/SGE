#!/usr/bin/python3
import re

class validarPass:

    def __init__(self,password):
        self.password = password
        
    def validar(self):
 
        if len(self.password) < 8:
            return False
        elif self.password.isalnum() or re.search(' ', self.password):
            return False
        elif len(self.password) > 12:
            return False
        else: 
            return True

if __name__ == "__main__":
    nuevoPass = validarPass("lsit-25465").validar()
    print(nuevoPass)