#!/usr/bin/python3

import psycopg2
from psycopg2 import Error

#pip install psycopg2

class Connection():

    def __init__(self):
        
        conn = None

    def get_connection(self):

        try:
            # Connect to an existing database
            self.conn = psycopg2.connect(user="postgres",
                password="",
                host="192.168.2.2",
                port="5432",
                database="tarea4")

            # Print PostgreSQL details
            #print("PostgreSQL server information")
            #print(self.conn.get_dsn_parameters(), "\n")

        except (Exception, Error) as error:
            print("Error while connecting to PostgreSQL", error)

        return self.conn

    def close_connection(self,conn):
        if (conn):
            conn.close()
            print("PostgreSQL connection is closed")

if __name__ == "__main__":
    connection = Connection()
    conn = connection.get_connection()
    connection.close_connection(conn)