#!/usr/bin/python3

from Ejercicio4 import Tablas
from Connection_postgresql import Connection
from prettytable import PrettyTable
import psycopg2
from psycopg2 import Error
from prettytable import PrettyTable
from prettytable import from_csv
from pathlib import Path
import csv

class Clientes_Proveedores():
    
    def __init__(self):
        conn = None 
        self.mi_tabla = PrettyTable()

    def inicio(self):
        conexion = Connection()
        self.conn = conexion.get_connection()
        self.comprobar_cliente()
        conexion.close_connection(self.conn)
    
    def comprobar_cliente(self):
        tablas= Tablas()
        self.mi_tabla = tablas.llenar_tabla("clientes.csv",self.mi_tabla)
        for row in self.mi_tabla:
            row.border = False
            row.header = False
            nombre = row.get_string(fields = ["Nombre cliente"]).strip()
            self.buscar_cliente(nombre)

                

    def buscar_cliente(self,nombre):
        cursor = self.conn.cursor()
        cursor.execute("select * from res_partner where name = '" + nombre + "'")
        rows = cursor.rowcount
        #print(rows)
        if rows == 1:
            for record in cursor:
                if record[1] == nombre:
                    #self.modificar_cliente(nombre,True,record[20],record[29],record[28],record[13],record[23],record[22])
                    sql = "UPDATE res_partner SET street = %s, phone = %s, email = %s, website = %s, city = %s, zip = %s where name = %s"
                    cursor.execute(sql,(record[20],record[29],record[28],record[13],record[23],record[22],nombre))
                    rows = cursor.rowcount
                    self.conn.commit()
                    print("Ciente " + nombre + " modificado")
                    #print(rows)
                else:
                    try:
                        sql = """INSERT INTO res_partner(name,street,phone,email,website,city,zip) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
                        cursor.execute(sql,(nombre,record[20],record[29],record[28],record[13],record[23],record[22]))
                        rows = cursor.rowcount
                        self.conn.commit()
                        print("Ciente " + nombre + " insertado")
                        #print(rows)
                    except (Exception, psycopg2.DatabaseError) as error:
                        print(error)
                    
            cursor.close()


if __name__ == "__main__":
    clientes = Clientes_Proveedores()
    clientes.inicio()