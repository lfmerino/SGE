#!/usr/bin/python3

import os
from prettytable import PrettyTable
#from prettytable import from_cursor
import psycopg2
from psycopg2 import Error
import Ejercicio4
from Connection_postgresql import Connection

#pip install prettytable
#pip install psycopg2

class Productos():

    def __init__(self):
        
        conn = None
        self.cod_producto = -1
        self.header_table_productos = ["ID Producto","Código Producto","Descripción","Stock"]
        self.tabla_productos = PrettyTable()
        self.tabla_productos.field_names = self.header_table_productos
        #print(dir(PrettyTable()))

    def mostrar_productos(self,conn):
        cursor = conn.cursor()
        cursor.execute("select id as ID_Producto,name as Descripcion from product_template " +
        "group by ID_Producto,Descripcion order by id")
        dic_cod = []
        if cursor != None:
            for record in cursor:
                dic_cod.append(record[0])
                #print(dic_cod)
                print(str(record).replace("(", "").replace(")", "").replace(",", ".").replace("'", ""))

        while True:
            try:
                self.cod_producto = int(input("\nIntroduzca el código del producto a consultar, teclee 0 para salir: "))
                if(self.cod_producto == 0):
                    break

                if self.cod_producto in dic_cod:   

                    cursor.execute("select product_id as ID_Producto, f2.default_code as Codigo_Producto, name as Descripcion, sum(product_qty) as Stock " +
                        "from stock_inventory_line f1, product_product as f2, product_template as f3 " +
                        "where product_id = " + str(self.cod_producto) + " and product_id = f2.product_tmpl_id and f2.product_tmpl_id = f3.id " +
                        "group by ID_Producto, Codigo_Producto, Descripcion " +
                        "order by Descripcion")

                    if cursor != None:
                        i = 0
                        for record in cursor:
                            self.tabla_productos.add_row(record)
                            #print(record)
                            print(self.tabla_productos)
                            self.tabla_productos.clear_rows()
                            i+=1
                        if i == 0:
                            print("El producto solicitado no esta en stock.")
                else:
                    print("El producto marcado no existe.")

            except:
                print("Ha ocurrido un error" + str(Error()))

    def crear_csv(self,conn):
        
        cursor = conn.cursor()
        cursor.execute("select product_id as ID_Producto, f2.default_code as Codigo_Producto, name as Descripcion, sum(product_qty) as Stock " +
                    "from stock_inventory_line f1, product_product as f2, product_template as f3 " +
                    "where product_id= f2.product_tmpl_id and product_id = f3.id " +
                    "group by ID_Producto, Codigo_Producto, Descripcion " +
                    "order by Descripcion")
        if cursor != None:
            for record in cursor:
                self.tabla_productos.add_row(record)
                #print(record)
            #print(self.tabla_productos)
            csv_file = Ejercicio4.Tablas().crear_csv("productos.csv",self.tabla_productos,self.header_table_productos)
            print("Fichero productos.csv creado correctamente")

    def inicio(self):
        respuesta = 0
        con_import = Connection()
        self.conn = con_import.get_connection()

        while respuesta >= 0 and respuesta < 3:
            try:
                print("")
                print("0. Salir")
                print("1. Mostrar productos")
                print("2. crear csv de productos")
                respuesta = int(input("Elija una opción: "))
                print("")
            except:
                respuesta = 5

            if respuesta == 0:
                exit()
            elif respuesta == 1:
                self.mostrar_productos(self.conn)
            elif respuesta == 2:
                self.crear_csv(self.conn)
            else:
                respuesta = 0

        con_import.close_connection(self.conn)
        
if __name__ == "__main__":
    mi_producto = Productos()
    mi_producto.inicio()