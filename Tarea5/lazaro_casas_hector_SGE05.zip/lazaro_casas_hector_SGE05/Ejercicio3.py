#!/usr/bin/python3

import Ejercicio1
import Ejercicio2
       
def pedir_usuario():

    valorUsuario = 1
    while (valorUsuario != 0):
        usuario=input("Introduzca nombre de usuario: ")
        valorUsuario = Ejercicio1.validarUser(usuario).validar()
        if valorUsuario == 1:
            print("\tEl nombre de usuario debe contener al menos 6 caracteres")
        if valorUsuario == 2:
            print("\tEl nombre de usuario no puede contener más de 12 caracteres")
        if valorUsuario == 3:
            print("\tEl nombre de usuario puede contener solo letras y números")
    return usuario

def pedir_password():

    valorPassword = False
    while (valorPassword != True):

        password=input("Introduzca la contraseña: ")
        valorPassword = Ejercicio2.validarPass(password).validar()
        if valorPassword == False:
            print("\tContraseña incorrecta, debe contener entre 8-12 digitos entre ello letras,números y un signo")
    return password
    #print("Nombre de usuario y contraseña correctos.")

if __name__ == "__main__":
    pedir_usuario()
    pedir_password()