#!/usr/bin/python3

class validarUser:

    def __init__(self,usuario):
        self.usuario = usuario
        
    def validar(self):
    
        if len(self.usuario) < 6:
            valor = 1

        elif self.usuario.isalnum() == False:
            valor = 3

        elif len(self.usuario) > 12:
            valor = 2
     
        else: 
            valor = 0

        return valor

if __name__ == "__main__":   
    nuevoUsuario = validarUser('juanpedro23').validar()
    print(nuevoUsuario)