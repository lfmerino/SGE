# -*- coding: utf-8 -*-

import psycopg2
import pandas as pd
import csv
import usuarios
import password
#import tablas

conexion = psycopg2.connect (host="localhost",
				database="Odoo14",
				user="postgres",
				password="Carla2017")

cursor = conexion.cursor()

#continuar = True
df = "Vacia"


class Stock:

	def __init__ (self, producto):

		self.df = producto

	try:
#		if continuar == True:

		df = pd.read_sql_query('''SELECT product_product.id,product_product.default_code
FROM product_product order by id''', conexion)

		print (df)

#		codigo = input("Ingrese el codigo de un articulo: ")

		registros = cursor.execute ('''select product_product.id, product_product.default_code,
product_template.name, stock_quant.quantity
from product_product, stock_quant, product_template
where stock_quant.product_id = product_product.id and location_id = 8
and product_product.product_tmpl_id = product_template.id
order by product_product.id;''')


		input("\nEsta es la tabla de los productos, presiona enter para ver articulos con stock\n")

		filas = cursor.fetchall()

		for fila in filas:
			print ("Id:", fila[0],"Codigo:", fila[1], "Descripcion:", fila[2], "Cantidad stock:", fila[3])
#		else:
#			print ("\nNo existe el producto")
	except:

		print ("algo falla")


#			try:
#
#				nid=input ("\nSelecciona un ID para ver el Código, la descripcion y el stock actual: ")
#				x=df['id'].index(nid)
#				y=x+1
#				if nid in df['id']:
#					print (df[x,y])
#			except:
#
#				print ("algo falla")
#			df = pd.read_sql_query('SELECT product_product.id, product_product.default_code,
# product_template.name FROM product_product, product_template
# where product_product.product_tmpl_id = product_template.id
# order by id
# ,conexion)

#	except:

#		print ("algo falla")

#registros = "select stock_quant.quantity from stock_quant"
#where stock_quant.product_id = 17
#and purchase_order_line.product_id = 17 and location_id = 8

#nombre = input("Seleciona id: ")

#nombre = input()
#if (nombre in fila):
#	print (fila)
	try:
		input("\n Presiona enter para crear un archivo .csv con los productos en stock")

		print ("\n")

		tabla = cursor.execute('''select product_product.id, product_product.default_code,
product_template.name, stock_quant.quantity
from product_product, stock_quant, product_template
where stock_quant.product_id = product_product.id and location_id = 8
and product_product.product_tmpl_id = product_template.id
order by product_template.name ''')

#tabla.to_csv('/usr/python3/dist-packages/odoo/addons/sge/tarea5.5.csv')

		filas = cursor.fetchall()
		for fila in filas:
	#print ("Id:", fila[0],"Codigo:", fila[1], "Descripcion:", fila[2], "Cantidad stock:", fila[3])

			with open (input ("Seleccione la ruta: "),'w',newline='')as archivo:
				writer = csv.writer(archivo,delimiter=';')
				writer.writerows(filas)

				print ("\nEl archivo se ha creado correctamente\n")
				break
	except:
		print ("\nHay un error")

conexion.commit()
conexion.close()
