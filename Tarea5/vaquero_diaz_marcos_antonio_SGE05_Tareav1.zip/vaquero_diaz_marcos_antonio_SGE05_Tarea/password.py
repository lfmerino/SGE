# -*- coding: utf-8 -*-

class Usuarios: #Creamos la clase usuarios

	Valido = False
	Login = "Incorrecta"

	def __init__ (self,password): #Definimos el objeto
		try:
			if len(password) > 7:
				self.Login = password
		except:
			print ("La contrañesa debe de ser un string")
	def validarPassword (self,password):

		try:

			long=len(password) #Calcula la longitud de la cadena de caracteres
			x=password.isalnum() #Calcula que la cadena de caracteres es alfanúmerica
			num=False #Guarda si tiene números
			may=False #Guarda si tiene mayúsculas
			min=False #Guarda si tiene minúsculas

			if long < 8 and x: #Comprueba que tiene más de 8 caracteres y no es alfanúmerico
				self.Valido = False

			for car in password: #Comprueba que son verdaderas todas las condiciones

				if car.isspace(): #Comprueba si tiene espacios
					self.Valido = False
					print ("No puede tener espacios")

				if car.isdigit(): #Comprueba si tiene números
					num = True

				if car.isupper(): #Comprueba si tiene mayúsculas
					may = True

				if car.islower(): #Comprueba si tiene minúsculas
					min = True

			if long <8 and x or(num == False or may == False  or min == False): #Comprueba que la contraseña no es segura
				print ("La contraseña no es segura")
				self.Valido = False

			if long >= 8 and x==False and num and may and min: #Devuelve true si contiene al menos caracter num, may, min
				print ("La contraseña es segura")
				self.Valido = True
				self.Login = password
		except:
			print ("Ha ocurrido un error")
