# -*- coding: utf-8 -*-

import os
import psycopg2
#from psycopg2 import extras
import pandas as pd
import csv
import usuarios
import password
from random import choice
from random import sample
import time
#import tablas
#import modulo_stock

os.system ("clear")

conexion = psycopg2.connect (host="localhost",
                                database="Odoo14",
                                user="postgres",
                                password="Carla2017")

cursor = conexion.cursor()

class clientesProveedores:


	tabla_tempx = "public.tmp_x" #Tabla temporal
	tabla_odoo = "public.res_partner" #Tabla odoo
	tabla_login = "public.res_login" #Tabla login
	tabla_tempy = "public.tmp_y" #Tabla temporal
	opc = "S"

	while (opc.upper() != "N"):

		print ('''
Que desea hacer:

1 - Importar un fichero .csv para añadir o actualizar la tabla usuarios
2 - Crear login y password del fichero .csv
3 - Ver listado de clientes/proveedores
4 - Salir''')

		opc = input()

		if opc == '1':

			try:

				crearTabla = "create table if not exists " +tabla_tempx+ '''(id integer,
name character varying,commercial_partner_id integer, website character varying, street character varying,
zip character varying, city character varying, email character varying, phone character varying);'''
#Crear tabla temporal
				cursor.execute(crearTabla)

				actualizarTabla = '''update res_partner set id=tmp_x.id, name=tmp_x.name,
commercial_partner_id=tmp_x.commercial_partner_id, website=tmp_x.website, street=tmp_x.street, zip=tmp_x.zip,
city=tmp_x.city, email=tmp_x.email, phone=tmp_x.phone from tmp_x where tmp_x.id=res_partner.id;''' 
#Actualizar tabla

				borrarTabla ="drop table " +tabla_tempx+ ";" #Borrar tabla temporal


				insertar = '''insert into res_partner (id,name,commercial_partner_id,
website,street,zip,city,email,phone) select id,name,commercial_partner_id,website,street,zip,city,
email,phone from tmp_x on conflict do nothing;''' #Insertar datos nuevos

				with open (input("\n Selecciona la ruta del archivo a importar sin cabecera: ")\
,'r') as f:

					cursor.copy_from (f, tabla_tempx, columns =\
('id','name','commercial_partner_id','website','street','zip','city','email','phone') ,sep= ';', null='',)
					#Copiar los datos del archivo .csv a la tabla temporal
					conexion.commit()
					cursor.execute (actualizarTabla) #Actualiza la tabla
					rowcount = cursor.rowcount #Cuenta las filas actualizadas
					print ("\nLineas actualizadas: ")
					print (rowcount) #Muestra en pantalla el numero de filas actualizadas
					cursor.execute (insertar) #Inserta en la tabla
					rowcount = cursor.rowcount #Cuenta las filas insertadas
					print ("\nLineas nuevas: ")
					print (rowcount) #Muestra en pantalla el numero de filas insertadas
					cursor.execute (borrarTabla) #Borra tabla temporal
					opc = input ("\nDesea continuar (S/N): ")

					if opc.upper()!= "S":
						if opc.upper()!= "N":
							print ("\nOpción incorrecta selecciones (S/N)")
							opc = input ("\n¿Desea continuar? (S/N); ")
			except:
				print ("Hay un error")

		if opc == "2":

			try:

				crearTabla = "create table if not exists " +tabla_login+ ''' 
(id integer references res_partner (id) unique, Login character varying, Password character varying,
primary key (id,Login,Password));''' #Crea tabla para guardar los datos del id, login y password
				cursor.execute(crearTabla)
				conexion.commit()

				crearTablaTemp = "create table if not exists " +tabla_tempy+ ''' 
(id integer references res_partner (id) unique, Login character varying,Password character varying)''' 
#Crea tabla temporal
				cursor.execute(crearTablaTemp)
				conexion.commit()

				actualizarTabla="update " +tabla_login+ ''' set id=tmp_y.id, Login=tmp_y.Login,
Password=tmp_y.Password from tmp_y where tmp_y.id=res_login.id;''' #Actualiza la tabla login

				insertar = "insert into " +tabla_login+ ''' (id,Login,Password) select id,Login,
Password from tmp_y on conflict do nothing;''' #Inserta en la tabla login

				borrarTabla ="drop table " +tabla_tempy+ ";" #Borra tabla temporal
				try:
					df=pd.read_csv(input\
("\n Selecciona el archivo .csv con los datos para crear el login y password: ")\
, delimiter=";") #Selecciona el archivo para leer

				except:
					print ("\nLa ruta no existe")

				nomb=df['name'].str.split(expand=True) #Selecciono el nombre y divido en 3
				nomb.columns = ['Nombre','Apellido1','Apellido2'] #Nombro las 3 columnas
				dfid=df['id'] #Rescato la id para asociar despues el login y el password a id
				nombre=pd.concat([dfid,nomb], axis=1)
				nombre["Login"]=nombre['Nombre'].str[0] + nombre['Apellido1'] #Creo el login
				nombre["Login"]=nombre["Login"].str.lower() #Pongo el login en minisculas
				dflog=nombre['Login'] #Pongo el login en una variable
				ha = time.strftime("%H", time.gmtime()) #Variable de hora actual
				ma = time.strftime("%M", time.gmtime()) #Variable de minutos actuales
				sa = time.strftime("%S", time.gmtime()) #Variable de segundos actuales
				lista =["$","%","&"] #Los 3 simbolos del final del password en una variable
				simb = choice (lista) #Elige uno de los 3 simbolos al azar
				aleatorio = nomb.sample(3, axis=1) #Barajea 3 columnas nuevas
				x = aleatorio.iloc[:,1].str[2] #Coge el 3 caracter del segundo elemento
				x = x.str.upper() #Dicho caracter lo convierte en mayusculas
				password=aleatorio.iloc[:,0].str[0]+sa+aleatorio.iloc[:,1].str[1]\
+x+ma+aleatorio.iloc[:,1].str[3]+simb #Localiza los caracteres que pide, ademas de las variables antes creadas
				loginPassword=pd.concat([dfid,dflog,password], axis=1) #Une id, login y password
				loginPassword.to_csv(input\
("\n Selecciona ruta para guardar el archivo .csv con los datos: ")\
, index= False, header= False) #No he encontrado otra manera de pasar estos datos a una tabla de odoo

				with open (input ("\n Selecciona el archivo .csv guardado con los datos: ")\
,'r') as f: #Abre al archivo que acabamos de guardar, aunque se le da a elegir la ruta
					cursor.copy_from (f, tabla_tempy, columns =('id','Login','Password')\
,sep= ',', null='', ) #Copia a la tabla temporal los datos del archivo
					conexion.commit()

					cursor.execute (actualizarTabla) #Actualiza Tabla
					rowcount = cursor.rowcount #Cuenta filas actualizadas
					print ("\nLineas actualizadas: ")
					print (rowcount) #Muestra en pantalla la cantidad de filas actualizadas
					cursor.execute (insertar) #Inserta datos nuevos
					rowcount = cursor.rowcount #Cuenta los datos insertados
					print ("\nLineas nuevas: ")
					print (rowcount) #Muestra en pantalla la cantidad de filas insertadas
					cursor.execute (borrarTabla) #Borra la tabla temporal
					conexion.commit()
					opc = input ("\nDesea continuar (S/N): ")

					if opc.upper()!= "S":
						if opc.upper()!= "N":
							print ("\nOpción incorrecta selecciones (S/N)")
							opc = input ("\n¿Desea continuar? (S/N); ")

			except:
				print ("Hay un error")


		if opc == "3":

			try:
# Este apartado se que esta mal, pero no me sale para que escoja uno y lo modifique
				seleccionar = "select id, name from res_partner order by id;"
				cursor.execute (seleccionar)
				filas = cursor.fetchall()
				for fila in filas :
					print (fila)
				opc = input ("\n¿Desea modificar algun registro? (S/N); ")
				if opc.upper()!= "S":
					if opc.upper()!= "N":
						print ("\nOpción incorrecta selecciones (S/N)")
						opc = input ("\n¿Desea modificar algun registro? (S/N); ")

				seleccion=(input ("\nSelecciona una id: "))
				actualizado=str(input ("\nIntoduce el nombre que quieres modificar: "))
				actualizar = "update res_partner set res_partner.name = " +actualizado+ " where res_partner.id = " +seleccion+  ";"
#				psycopg2.extras.execute_values (cursor, actualizar, new_values, template=None)
				cursor.execute (actualizar)
				conexion.commit()
				opc = input ("\n¿Desea continuar? (S/N); ")
				if opc.upper()!= "S":
					if opc.upper()!= "N":
						print ("\nOpción incorrecta selecciones (S/N)")
						opc = input ("\n¿Desea continuar? (S/N); ")
			except:
				print ("\nHay algun error")
		if opc == "4":
			opc = "N"
conexion.commit()
conexion.close()
