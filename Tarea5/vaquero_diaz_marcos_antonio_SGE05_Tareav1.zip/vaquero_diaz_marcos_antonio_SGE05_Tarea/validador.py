# -*- coding: utf-8 -*-

import usuarios
import password

opc = "S" #Asignamos "S" a la variable opc.
us = usuarios.Usuarios("") #Asignamos parte de la ruta a la variable us
ps = password.Usuarios("") #Asignamos parte de la ruta a la variable ps

''' He creado 3 ciclos, 1 para usuario, 1 para contraseña y otro que englobe los dos, me di cuenta que de
esa forma cuando validas la contraseña y le das a siguiente te lleva a usuario otra vez, asi puedes validar
varios usuarios y contraseñas de una misma vez'''

while (opc.upper()!= "N"):

	'''Le decimos que si la opcion es distinta a N compruebe lo siguiente, ademas como no sabemos
	si lo escribe en mayusculas o minisculas,le decimos que escrito lo convierta en mayusculas'''

	while (opc.upper()!= "N"):
		us.validarUsuario(input("Introduce el usuario: ")) #Comprobamos si el usuario cumple las pautas
		print ("\nEl login generado es: "+us.Login)
		opc = input ("\nDesea continuar? (S/N): ") #Damos opcion de continuar

		if opc.upper()!= "S": # Si la opcion pulsada es diferente a "S" comprueba lo siguiente
			if opc.upper()!= "N": # Si la opcion pulsada es diferente a "N" hace lo siguiente.
				print ( "\nOpcion incorrecta seleccione (S/N)")
				opc = input ("\nVolver a intentarlo? (S/N): ")
		if us.Valido:
			break #Cuando el usuario es valido le decimos que corte el ciclo para pasar al password

	while (opc.upper()!= "N"):
		ps.validarPassword(input("\nIntroduce la contraseña: ")) #Comprueba si la contraseña sigue las pautas
		print ("\nLa contraseña generada es: "+ps.Login)
		opc = input ("\nDesea continuar? (S/N): ") #Damos opcion de continuar

		if opc.upper()!= "S": # Si la opcion pulsada es diferente a "S" comprueba lo siguiente
			if opc.upper()!= "N": # Si la opcion pulsada es diferente a "N" hace lo siguiente.
				print ( "\nOpcion incorrecta seleccione (S/N)")
				opc = input ("\nDesea continuar? (S/N): ")
		if ps.Valido:
			break #Cuando la contraseña es valida le decimos que corte el ciclo para pasar a usuario
