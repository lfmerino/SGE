# -*- coding: utf-8 -*-

class Usuarios: #Creamos la clase

	Valido = False #Variable para saber si el usuario es valido
	Login = "Incorrecto" #Variable mostar luego el usuario creado

	def __init__(self,nombre): #Definimos el objeto
		try:
			if len(nombre) > 5:
				self.Login = nombre
		except:
			print ("El nombre dede de ser un string")
	def validarUsuario(self,nombre):
		try:

			long=len(nombre) #Calcula la longitud de la cadena de caracteres
			x=nombre.isalnum() #Calcula que la cadena de caracteres sea alfanumérico
			y=long >5 and long <13 and x #La variable y es igual al nombre de usuario correcto

			if not x: #Comprueba que no es alfanumérico
				print ("El nombre de usuario puede contener solo letras y números")
			elif long >5 and long <13 and x: #Comprueba que tenga entre 6 y 12 caracteres y que sea alfanumérico
				print ("El nombre de usuario es válido")
			elif long <6: #Comprueba si tiene menos de 6 caracteres
				print ("El nombre de usuario debe contener al menos 6 caracteres")
			elif long >12: #Comprueba si tiene más de 12 caracteres
				print ("El nombre de usuario no puede contener más de 12 caracteres")
			if y: #Si la variable y es true devuelve true y el usuario estaria creado
				self.Valido = True #El login es valido
				self.Login = nombre #Ponemos el nombre introducido a la variable

		except: #Si hay algo mal sale un mensaje avisandolo
			print ("Ha ocurrido un error")
