
# -*- coding: utf-8 -*-

import os
import pandas as pd
import password
from datetime import date
from datetime import datetime
#from itertools import chain
#from collections import defaultdict
ps = password.Usuarios("")

#def buscar_dicc(it: Iterable[dict], clave: Hashable, valor: Any) -> Optional[dict]:
#	for dicc in it:
#		if dicc[clave] == valor:
#			return dicc
#	return None

os.system("clear") #Limpiamos la consola.

class Personas: # Creamos la clase

	tabla = {'Apellidos':['tony','andres'],
		'Nombre':['yo','tu'],
		'Fecha_nacimiento':['12/07/1900','12/09/1956'],
		'Direccion':['afdsa','gfdsgs'],
		'Contraseña':['sdf','fgg']}

	tabla_datos = pd.DataFrame(tabla)
	tabla_datos

	def __init__ (self,datos): #Definimos el objeto

		self.datos = tabla

	def introducirDatos (self,datos):

		self.datos = tabla

	print ("\n")
	print (tabla_datos)
	salir = False
	datos = tabla
	while (not salir):

		opcion=input("\nElige una de estas opciones \n\
1 - Almacenar datos\n\
2 - Buscar datos\n\
3 - Añadir datos a un fichero .csv\n\
4 - Recuperar datos de un fichero .csv\n\
5 - Salir\n\
Opcion: ")

		if opcion == '1':

			try:
				tabla['Apellidos'].append (input("Introduce los apellidos: "))
				tabla['Nombre'].append (input("Introduce el nombre: "))
				try:
					nacimiento =(input("Introduce la fecha de nacimiento (dd/mm/yyyy): "))
					objDate = datetime.strptime(nacimiento, '%d/%m/%Y')
					objDate
					tabla['Fecha_nacimiento'].append (nacimiento)
				except ValueError:
					print ("\nFormato erroneo\n")

				tabla['Direccion'].append (input("Introduce la direccion: "))
				cont=input("Introduce la contraseña: ")
				ps.validarPassword (cont)
				tabla['Contraseña'].append (cont)
				tabla_datos = pd.DataFrame(tabla)
				tabla_datos
				print ("\nTabla de datos actual\n")
				print (tabla_datos)

			except ValueError:
				print ("\nHa ocurrido un error\n")

		elif opcion == '2':

			opcion=input("Seleccione una opcion\n\
1 - Nombre\n\
2 - Apellidos\n\
Opcion: ")
			if opcion == '1':

				try:
					nomb=input("Nombre: ")
					x=tabla['Nombre'].index(nomb)
					y=x+1
					if nomb in tabla['Nombre']:
						print (tabla_datos[x:y])

				except ValueError:
					print ("\nEl nombre buscado no existe\n")

			elif opcion == '2':

				try:

					nomb=input("Apellidos: ")
					x=tabla['Apellidos'].index(nomb)
					y=x+1
					if nomb in tabla['Apellidos']:
						print (tabla_datos[x:y])

				except ValueError:
					print ("\nEl apellido buscado no existe\n")

			else:
				print ("\nLa opcion elegida es incorrecta\n")

		elif opcion == '3':

			try:
				tabla_datos.to_csv(input ("Seleccione la ruta: "))
				print ("\nFichero creado correctamente\n")

			except FileNotFoundError:
				print ("\nLa ruta no existe\n")

		elif opcion == '4':
			try:

				d=pd.read_csv(input ("Seleccione el archivo a recuperar: "))
				print ("\nTabla importada\n")
				print (d)
				td = pd.concat([tabla_datos, d],axis=0)
				td.index=range(td.shape[0])
#				print (td)
				td = td.to_dict('list')
#				print (td)
				tabla = td
#				print (tabla)
#				frames = [tabla_datos, d]
#				result = pd.concat (frames)
#				result.indexrange
#				print (result)
#				tabla.update(d1)
#				print (tabla)

#				d2 = defaultdict(list)
#				for k, v in chain (tabla.items(), d1.items()):
#					d2[k].append(v)
#				for k, v in d2.items():
#					print (k,v)
#				tabla = d2
#			tabla_datos = pd.DataFrame(tabla,columns= ['Apellidos','Nombre','Fecha_nacimiento','Direccion', 'Contraseña'])
#			tabla_datos
#			tabla_datos.append (d)
#				tabla_datos = pd.concat([tabla_datos, d],axis=0)
#			tabla_datos
#				tabla_datos.index=range(tabla_datos.shape[0])
#			prueba = pd.DataFrame (tabla_datos)
#			prueba
#			tabla_datos = prueba
#			ids=pd.DataFrame(tabla_datos)
#			({'id':[]},columns=['Apellidos'])
#			tabla_datos=pd.concat([ids,tabla_datos],axis=1)
#			tabla_datos

#				tabla['Apellidos'].append (d1['Apellidos'])
#				tabla['Nombre'].append (d1['Nombre'])
#				tabla['Fecha_nacimiento'].append (d1['Fecha_nacimiento'])
#				tabla['Direccion'].append(d1['Direccion'])
#				tabla['Contraseña'].append(d1['Contraseña'])
				tabla_datos = pd.DataFrame(tabla)
				print ("\nTabla de datos actual\n")
				print (tabla_datos)
				print ("")
#			self.tabla = datos

			except FileNotFoundError:
				print ("\nLa ruta no existe\n")

		elif opcion == '5':
			salir = True
		else:
			print ("\nLa opcion elegida es incorrecta\n")
