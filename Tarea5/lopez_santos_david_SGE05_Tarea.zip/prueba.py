import sge05
from sge05.ejercicio1.usuarios import Usuarios
from sge05.ejercicio2.passwords import Passwords
from sge05.ejercicio3.user_manager import GestorUsuarios
from sge05.ejercicio4.tablas import Tablas
from sge05.ejercicio5.productos import GestorProductos
from sge05.ejercicio6.clientes import GestorClientes

#Ejercicio 1
#usuarios = Usuarios()
#print(usuarios.validarUsuario("123"))

#Ejercicio 2
#passwords = Passwords()
#print(passwords.validarPassword("123"))

#Ejercicio 3
#GestorUsuarios()

#Ejercicio 4
#Tablas().mostrarMenu();

#Ejercicio 5
#GestorProductos().mostrarMenu()

#Ejercicio 6
GestorClientes().mostrarMenu()