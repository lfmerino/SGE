import xmlrpc.client
import datetime
import os
import csv

class Utilidades():
	def __init__(self):
		self.url = "http://192.168.2.3:8069"
		self.db = "odoo"
		self.username = "david.lopez.santos@gmail.com"
		self.password = "123456"

	def getUrl(self):
		return self.url

	def getDatabase(self):
		return self.db

	def getUsername(self):
		return self.username

	def getPassword(self):
		return self.password

	def getCommon(self):
		return xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(self.url))

	def getUID(self):
		# Nos identificamos
		return self.getCommon().authenticate(self.db, self.username, self.password, {})

	# Funcion para borrar la pantalla
	@staticmethod
	def borrarPantalla():
		if os.name == "posix":
			os.system ("clear")
		elif os.name == "ce" or os.name == "nt" or os.name == "dos":
			os.system ("cls")

	# Funcion para obtener los modelos de python
	def getModelos(self):
		# Configuramos los modelos
		return xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(self.getUrl()))