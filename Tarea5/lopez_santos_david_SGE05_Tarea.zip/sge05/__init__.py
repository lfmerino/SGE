# -*- coding: utf-8 -*-

from . import ejercicio1
from . import ejercicio2
from . import ejercicio3
from . import ejercicio4
from . import ejercicio5
from . import ejercicio6
from . import utilidades