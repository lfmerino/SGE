
class Passwords():
	def validarPassword(self, password):
		# Definimos la salida
		output = True 
		# Cadena más corta que 8 caracteres
		output = False if (len(password) < 8) else output
		# Contiene espacios
		output = False if (' ' in password) else output
		# Cadena no contiene simbolo
		output = False if (password.isalnum() and len(password) > 0) else output
		# Devolvemos la salida
		return output