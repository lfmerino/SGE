import csv 
from sge05.utilidades.utilidades import Utilidades

class GestorProductos():
	# Método de inicio, obtenemos los datos de configuracion
	def __init__(self):
		utilidades = Utilidades()
		self.models = utilidades.getModelos()
		self.db = utilidades.getDatabase()
		self.uid = utilidades.getUID()
		self.password = utilidades.getPassword()

	# Metodo que muestra el menu
	def mostrarMenu(self):
		# Método para listar los registros
		def listarRegistros():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Obtenemos los registros
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'product.product', 'search_read', [], 
				{'fields': ['id', 'name', 'description', 'qty_available']})

			# Los mostramos
			imprimirRegistros(records)

		# Método para exportar a CSV
		def exportarRegistros():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Cabecera
			print("EXPORTAR REGISTROS ", 30 * "-")

			# Leemos los registros
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'product.product', 'search_read', [], 
				{'fields': ['id', 'name', 'description', 'qty_available'], 'order': 'description asc'})

			# Exportamos datos
			with open('productos_out.csv', 'w') as file_output:
				w = csv.DictWriter(file_output, ('id', 'name', 'description', 'qty_available'))
				w.writeheader()
				for registro in records: 
					w.writerow(registro)

			print("Productos exportados correctamente en productos_out.csv")
			input("Pulsa cualquier tecla para continuar...")

		# Método para buscar registros
		def buscarRegistros():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Pedimos datos
			print("BUSCAR REGISTRO ", 30 * "-")

			# Busqueda
			busqueda = input("Introduce la búsqueda (código o nombre/descripcion): ")

			# Obtenemos los registros por Codigo
			if busqueda.isnumeric():
				records = self.models.execute_kw(self.db, self.uid, self.password,
				'product.product', 'search_read', 
				[[['id', '=', busqueda]]],
				{'fields': ['id', 'name', 'description', 'qty_available']})
			# Obtenemos los registros por nombre/descripcion
			else:
				records = self.models.execute_kw(self.db, self.uid, self.password,
				'product.product', 'search_read',
				[['|', ['name', 'ilike', busqueda], ['description', 'ilike', busqueda]]],
				{'fields': ['id', 'name', 'description', 'qty_available']})

			# Los imprimimos
			imprimirRegistros(records)

		# Método para imprimir los registros
		def imprimirRegistros(registros):
			# Mostramos la cabecera
			print ("{:<10} {:<20} {:<30} {:<10}".format('CODIGO', 'NOMBRE', 'DESCRIPCION', 'CANTIDAD')) 
			
			# Si no tenemos registros
			if len(registros) == 0:
				print("NO HAY RESULTADOS")
			# Si los tenemos
			else:
				# Imprimimos cada uno
				for registro in registros: 
					print ("{:<10} {:<20} {:<30} {:<10}".format(
						str(registro['id'])[0:10].ljust(10), 
						str(registro['name'])[0:20].ljust(20), 
						str(registro['description'])[0:30].ljust(30), 
						str(registro['qty_available'])[0:10].ljust(10)))
			
			input("Pulsa cualquier tecla para continuar...")

		# Imprimimos el menu
		def imprimirMenu():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			print(30 * "-", "EJERCICIO 5", 30 * "-")
			print("1. Listar productos ")
			print("2. Buscar productos ")
			print("3. Exportar productos ")
			print("0. Salir ")
			print(73 * "-")

		continuar = True

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			imprimirMenu()
			
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-3]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				listarRegistros()
			elif opcion == '2':
				buscarRegistros()
			elif opcion == '3':
				exportarRegistros()
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mostramos error
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]