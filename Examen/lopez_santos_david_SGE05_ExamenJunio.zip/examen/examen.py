import os,sys,inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))

import csv
import datetime
import random

from modulos.clientes import GestorClientes
from modulos.utilidades import Utilidades
from modulos.passwords import Passwords

class ExamenJunio():
	# Método de inicio, obtenemos los datos de configuracion
	def __init__(self):
		# Modulos anteriores
		self.utilidades = Utilidades()
		self.clientes = GestorClientes()
		self.passwords = Passwords()

		# Variables de configuracion
		# Cabecera del fichero esperada
		self.header = ('nombre','email','sexo')
		# Nombre del fichero a importar. Si se quiere pedir por consola, comentar línea 79 y descomentar linea 78
		self.archivo_usuarios = "usuarios.csv"
		
		# Valores por defecto
		self.default_values = {
			'password': "Cam5iar$",
			'lang': 'es_ES',
			'commercial_partner_id': 2,
			'create_uid': 2,
			'write_uid': 2,
			'notification_type': 'email'
		}

		# Obtenemos el company id
		self.company_id = self.obtenerCompanyId()

	def probarPassword(self, nombre):
		try:
			print(self.clientes.crearPassword(nombre))
		except:
			print("error")

	def existeRegistroUsuario(self, login):
		# Inicializamos la salida
		salida = False

		# Comprobamos que existe
		consulta = "SELECT id, login FROM res_users WHERE login=%s"
		registros = self.utilidades.ejecutarConsulta(consulta, (login,))

		# El usuario existe
		if len(registros) != 0:
			salida = registros[0]['id']

		return salida

	def existeRegistroPartner(self, nombre):
		# Inicializamos la salida
		salida = False

		# Comprobamos que existe
		consulta = "SELECT id, name FROM res_partner WHERE name=%s"
		registros = self.utilidades.ejecutarConsulta(consulta, (nombre,))

		# El usuario existe
		if len(registros) != 0:
			salida = registros[0]['id']

		return salida

	def obtenerCompanyId(self):
		# Inicializamos la salida
		salida = 0

		# Comprobamos que existe
		consulta = "SELECT id, name FROM res_company ORDER BY id ASC LIMIT 1"
		registros = self.utilidades.ejecutarConsulta(consulta, ())

		# El usuario existe
		if len(registros) != 0:
			salida = registros[0]['id']

		return salida

	def obtenerSignature(self, nombre, sexo):
		# Inicializamos la salida
		salida = 0

		# Separamos nombre y apellidos
		componentes = nombre.split(" ")

		# Si nos faltan componentes en el array, o nos sobran, lo arreglamos
		if len(componentes) < 3:
			componentes += [componentes[0]] * (3 - len(componentes))
		elif len(componentes) > 3:
			componentes = componentes[0:3]

		if sexo.lower() == 'h':
			salida = "Sr. "+componentes[1]
		else:
			salida = "Sra. "+componentes[1]

		return salida

	# Método para importar los clientes desde el CSV
	def importarClientes(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()
		
		# Cabecera
		print("IMPORTAR CLIENTES", 30 * "-")

		# Inicializamos los registros
		registros = {}

		# Pedimos la ruta del archivo
		#archivo = input("Introduce la ruta del archivo a importar: ")
		archivo = self.archivo_usuarios
		
		# Comprobamos que el archivo exista
		try:
			reader = csv.DictReader(open(archivo, 'r'))

			# Si no tiene la longitud correcta...
			if (len(reader.fieldnames) != len(self.header)):
				print("Número de campos incorrectos. Debe tener "+str(self.header))
			elif (','.join(reader.fieldnames) != ','.join(self.header)):
				print("Cabecera del fichero incorrecta. Debe ser "+str(self.header))
			# Si la tiene, procesamos
			else:
				# Iniciamos los contadores
				registros_insertados = 0
				registros_modificados = 0
				registros_error = 0

				# Recorremos cada fila
				for row in reader:
					# Si tiene longitud incorrecta
					if len(row) != len(self.header):
						registros_error = registros_error + 1
					# Si es correcta, la procesamos
					else:
						# Procesamos el resultado
						resultado = self.procesarFila(row)

						# Insertado
						if resultado == 0:
							registros_insertados = registros_insertados + 1
						# Actualizado
						elif resultado == 1:
							registros_modificados = registros_modificados + 1
						# Error
						else:
							registros_error = registros_error + 1
						
				# Mostramos el conteo
				print(str(registros_insertados) + " registros insertados correctamente.")
				print(str(registros_modificados) + " registros modificados correctamente.")
				print(str(registros_error) + " registros con errores.")

		# Si no existe...
		except IOError:
			print("No se pudo acceder al fichero")

		input("Pulsa cualquier tecla para continuar...")

	# Método para procesar una fila del CSV
	def procesarFila(self, row):
		# Devolvemos -1 si hay error, 0 si insertamos, 1 si modificamos
		salida = -1

		# Generamos el login
		login = self.clientes.crearLogin(row['nombre'])
		# Generamos el password
		password = self.clientes.crearPassword(row['nombre'])
		if(self.passwords.validarPassword(password) == False):
			password = self.default_values['password']

		#Obtenemos la signature
		signature = self.obtenerSignature(row['nombre'], row['sexo'])

		# Comprobamos si existe el usuario
		user_id = self.existeRegistroUsuario(login)
		partner_id = self.existeRegistroPartner(row['nombre'])

		# Si no existe el usuario en la tabla...
		if user_id == False:

			# Si no existe el partner, lo insertamos
			if partner_id == False:
				created = True
				partner_id = self.insertaRegistroPartner(row['nombre'], row['email'])
			else:
				created = False

			# Insertamos el usuario
			user_id = self.insertaRegistroUsuario(login, password, partner_id, signature)

			# Actualizamos el user_id de la tabla res_partner
			if created == True:
				self.actualizaRegistroPartner(partner_id, user_id)
			
			salida = 0
		else:
			# Si no existe el partner, lo insertamos
			if partner_id == False:
				created = True
				partner_id = self.insertaRegistroPartner(row['nombre'], row['email'])
			else:
				created = False

			# Actualizamos el usuario
			self.actualizaRegistroUsuario(user_id, login, password, partner_id, signature)

			# Actualizamos el user_id de la tabla res_partner
			if created == True:
				self.actualizaRegistroPartner(partner_id, user_id)

			salida = 1

		return salida

	# Método para insertar un registro en la tabla res_users	
	def insertaRegistroUsuario(self, login, password, partner_id, signature):
		# Inicializamos la salida
		salida = False

		# Adecuamos los datos
		company_id = self.company_id
		create_date = datetime.datetime.now()
		write_date = create_date
		create_uid = self.default_values['create_uid']
		write_uid = self.default_values['write_uid']
		notification_type = self.default_values['notification_type']

		# Insertamos el usuario
		consulta = "INSERT INTO res_users (login, password, company_id, partner_id, create_date, write_date, signature, create_uid, write_uid, notification_type) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
		salida = self.utilidades.ejecutarInsercion(consulta, (login, password, company_id, partner_id, create_date, write_date, signature, create_uid, write_uid, notification_type))

		return salida

	# Método para insertar un registro en la tabla res_parner
	def insertaRegistroPartner(self, nombre, email):
		# Inicializamos la salida
		salida = False

		# Definimos los campos
		create_date = datetime.datetime.now()
		write_date = create_date
		lang = self.default_values['lang']
		commercial_partner_id = self.default_values['commercial_partner_id']
		create_uid = self.default_values['create_uid']
		write_uid = self.default_values['write_uid']

		# Insertamos en la tabla partners
		consulta = "INSERT INTO res_partner (name, display_name, create_date, write_date, lang, email, commercial_partner_id, create_uid, write_uid) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
		salida = self.utilidades.ejecutarInsercion(consulta, (nombre, nombre, create_date, write_date, lang, email, commercial_partner_id, create_uid, write_uid))

		return salida

	# Método para insertar un registro en la tabla res_parner
	def actualizaRegistroPartner(self, partner_id, user_id):
		# Inicializamos la salida
		salida = False

		# Actualizamos los ids
		consulta = "UPDATE res_partner SET user_id=%s WHERE id=%s"
		user_id = self.utilidades.ejecutarActualizacion(consulta, (user_id, partner_id))

		return salida

	# Método para insertar un registro en la tabla res_parner
	def actualizaRegistroUsuario(self, user_id, login, password, partner_id, signature):
		# Inicializamos la salida
		salida = False

		# Definimos los campos
		company_id = self.company_id
		write_date = datetime.datetime.now()
		write_uid = self.default_values['write_uid']

		# Actualizamos los ids
		consulta = "UPDATE res_users SET login=%s, password=%s, company_id=%s, partner_id=%s, write_date=%s, signature=%s, write_uid=%s  WHERE id=%s"
		user_id = self.utilidades.ejecutarActualizacion(consulta, (login, password, company_id, partner_id, write_date, signature, write_uid, user_id))

		return salida

if __name__ == "__main__":
	# Creamos la instancia
	instancia = ExamenJunio()
	instancia.importarClientes()