class Passwords():
	def validarPassword(self, password):
		# Definimos la salida
		output = True 
		# Cadena más corta que 8 caracteres
		output = False if (len(password) < 8) else output
		# Contiene espacios
		output = False if (' ' in password) else output
		# No contiene mayusculas
		output = False if not any(c.isupper() for c in password) else output
		# No contiene minusculas
		output = False if not any(c.islower() for c in password) else output
		# Cadena no contiene simbolo
		output = False if (password.isalnum() and len(password) > 0) else output
		# Devolvemos la salida
		return output

if __name__ == "__main__":
	# Creamos la instancia
	instancia = Passwords()

	# Definimos las cadenas de prueba
	pruebas = ['PAaS123-', 'pas 1234', 'EsAlnum123', 'Tiene-Simb']

	# Recorremos
	for item in pruebas:
		print("PRUEBA: '"+item+"'")
		print(instancia.validarPassword(item))