import os,sys,inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))

import csv

from usuarios import Usuarios
from passwords import Passwords
from utilidades import Utilidades

try:
	import pandas as pd
except:
	print("ERROR: Falta la librería pandas. Se puede instalar con 'pip install pandas'")
	exit()

class Tablas():
	# Metodo inicial
	def __init__(self):
		# Variable para la cabecera
		self.header = ['Nombre','Apellidos','Email']
		# Variable para el contenido
		self.content = []
		# Variable de utilidades
		self.utilidades = Utilidades()

	# Metodo para definir la cabecera del archivo
	def definirHeader(self, header):
		self.header = header

	def rellenarRegistros(self, registros):
		self.content = registros

	# Método para importar registros desde el CSV
	def importarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Cabecera
		print("IMPORTAR REGISTROS ", 30 * "-")

		# Inicializamos los registros
		registros = {}

		# Pedimos la ruta del archivo
		archivo = input("Introduce la ruta del archivo a importar: ")

		# Comprobamos que el archivo se pueda abrir y exista
		try:
			# Leemos el archivo
			reader = csv.DictReader(open(archivo, 'r'))

			# Comprobamos que la longitud de los registros es la misma que esperamos
			if (len(reader.fieldnames) == len(self.header)):
				# Sobreescribimos la cabecera
				self.header = reader.fieldnames

				# Contador de registros importados
				registros_importados = 0
				for row in reader:
					self.content.append(row)
					registros_importados = registros_importados + 1
					
				print(str(registros_importados) + " registros importados correctamente.")

			else:
				print("ERROR: El número de elementos del fichero no coincide")
			
		# El archivo no existe
		except IOError:
			print("No se pudo acceder al fichero")

		input("Pulsa cualquier tecla para continuar...")

	# Metodo para imprimir la tabla
	def imprimirRegistros(self, registros):
		print(pd.DataFrame(registros))
		input("Pulsa cualquier tecla para continuar...")

	# Método para exportar a CSV
	def exportarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Cabecera
		print("EXPORTAR REGISTROS ", 30 * "-")

		# Exportamos datos
		with open('registros_out.csv', 'w') as file_output:
			w = csv.DictWriter(file_output, self.header)
			w.writeheader()
			for registro in self.content: 
				w.writerow(registro)

		print("Registros exportados correctamente en registros_out.csv")
		input("Pulsa cualquier tecla para continuar...")

	# Metodo para buscar registros
	def buscarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Pedimos datos
		print("BUSCAR REGISTRO ", 30 * "-")

		# Busqueda
		busqueda = input("Introduce la búsqueda: ")

		# Variable para filtrar los registros
		filtrados = []

		# Recorremos y buscamos 
		for registro in self.content: 
			encontrado = False
			for clave in self.header:
				valor = str(registro[clave])
				if (str.lower(valor).find(str.lower(busqueda)) != -1) and not encontrado:
					filtrados.append(registro)
					encontrado = True

		# Si no tenemos resultados
		if len(filtrados) == 0:
			print("NO HAY RESULTADOS PARA: "+busqueda)
			input("Pulsa cualquier tecla para continuar...")
		# Si si que tenemos, los mostramos
		else:
			self.imprimirRegistros(filtrados)

	# Método para pedir los datos
	def pedirDatos(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Pedimos datos
		print("INTRODUCIR REGISTRO ", 30 * "-")

		try:
			# Inicializamos el diccionario
			item = {}

			for clave in self.header:
				valor = input("Introduce '"+clave+"':")
				item[clave] = valor

			self.content.append(item)
			print("Elemento agregado correctamente.")
		except:
			print("ERROR: No se pudo agregar el elemento")

		input("Pulsa cualquier tecla para continuar...")

	# Imprimimos el menu
	def imprimirMenu(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		print(30 * "-", "EJERCICIO 4", 30 * "-")
		print("1. Introducir registro manualmente ")
		print("2. Buscar registro ")
		print("3. Exportar registros a fichero CSV ")
		print("4. Importar registros de fichero CSV ")        
		print("5. Imprimir registros del diccionario ")        
		print("0. Salir ")
		print(73 * "-")
		
	# Método que muestra el menu principal
	def mostrarMenu(self):
		continuar = True
		int_choice = -1

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			self.imprimirMenu()
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-5]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				self.pedirDatos()
			elif opcion == '2':
				self.buscarRegistros()
			elif opcion == '3':
				self.exportarRegistros()
			elif opcion == '4':
				registros = self.importarRegistros()
			elif opcion == '5':
				self.imprimirRegistros(self.content)
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mensaje de error si no es una opción correcta
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]

if __name__ == "__main__":
	# Creamos la instancia
	instancia = Tablas()
	instancia.mostrarMenu()