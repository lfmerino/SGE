import os,sys,inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))) 

import csv
import datetime
import random

from tablas import Tablas
from utilidades import Utilidades

class GestorClientes():
	# Método de inicio, obtenemos los datos de configuracion
	def __init__(self):
		# Modulos anteriores
		self.utilidades = Utilidades()
		self.tablas = Tablas()
		self.header = ('name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id')

	# Método para crear el login
	def crearLogin(self, name):
		salida = ""

		# Separamos nombre y apellidos
		componentes = name.split(" ")

		# Si nos faltan componentes en el array, o nos sobran, lo arreglamos
		if len(componentes) < 3:
			componentes += [componentes[0]] * (3 - len(componentes))
		elif len(componentes) > 3:
			componentes = componentes[0:3]

		# Obtenemos el login
		salida = (componentes[0][0] + componentes[1]).lower()

		# Si existe, le añadimos numeros sucesivos hasta que tengamos uno libre.
		#contador = 0
		#while self.existeLogin(salida) == True:
		#	salida = (componentes[0][0] + componentes[1]).lower() + "_" + str(contador)
		#	contador = contador + 1

		return salida

	# Método para crear el password
	def crearPassword(self, name):
		salida = ""

		# Obtenemos los minutos y segundos actuales
		minutos = str(datetime.datetime.now().minute)
		segundos = str(datetime.datetime.now().second)
		caracteres = "%$&"

		# Separamos nombre y apellidos
		componentes = name.split(" ")

		# Si nos faltan componentes en el array, o nos sobran, lo arreglamos
		if len(componentes) < 3:
			componentes += [componentes[0]] * (3 - len(componentes))
		elif len(componentes) > 3:
			componentes = componentes[0:3]

		# Desordenamos el array
		random.shuffle(componentes)

		# Comenzamos a crear la cadena
		salida = componentes[0][0] + segundos

		# Ahora el apellido (si no tiene longitud suficiente, metemos --)
		if len(componentes[1]) < 3:
			salida = salida + minutos
		else:
			salida = salida + componentes[1][1] + componentes[1][2].upper() + minutos

		# Ahora el apellido2
		if len(componentes[2]) < 4:
			salida = salida + random.choice(caracteres)
		else:
			salida = salida + componentes[2][3] + random.choice(caracteres)
					
		
		return salida

	# Método para importar los clientes desde el CSV
	def importarClientes(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()
		
		# Cabecera
		print("IMPORTAR CLIENTES/PROVEEDORES ", 30 * "-")

		# Inicializamos los registros
		registros = {}

		# Pedimos la ruta del archivo
		archivo = input("Introduce la ruta del archivo a importar: ")
		
		# Comprobamos que el archivo exista
		try:
			reader = csv.DictReader(open(archivo, 'r'))

			# Si no tiene la longitud correcta...
			if (len(reader.fieldnames) != len(self.header)):
				print("Número de campos incorrectos. Debe tener 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id'")
			# Si la tiene, procesamos
			else:
				# Iniciamos los contadores
				registros_insertados = 0
				registros_modificados = 0
				registros_error = 0

				# Recorremos cada fila
				for row in reader:
					# Si tiene longitud incorrecta
					if len(row) != len(self.header):
						registros_error = registros_error + 1
					# Si es correcta, la procesamos
					else:
						# Procesamos el resultado
						resultado = self.procesarFila(row)

						# Insertado
						if resultado == 0:
							registros_insertados = registros_insertados + 1
						# Actualizado
						elif resultado == 1:
							registros_modificados = registros_modificados + 1
						# Error
						else:
							registros_error = registros_error + 1
						
				# Mostramos el conteo
				print(str(registros_insertados) + " registros insertados correctamente.")
				print(str(registros_modificados) + " registros modificados correctamente.")
				print(str(registros_error) + " registros con errores.")

		# Si no existe...
		except IOError:
			print("No se pudo acceder al fichero")

		input("Pulsa cualquier tecla para continuar...")

	# Método para procesar una fila del CSV
	def procesarFila(self, row):
		# Devolvemos -1 si hay error, 0 si insertamos, 1 si modificamos
		salida = -1

		# Comprobamos si existe el usuario
		usuarioExistente = self.obtenerClientePorNombre(row['name'])

		# Comprobamos si existe la categoria
		categoriaExistente = self.obtenerCategoriaPorNombre(row['category_id'])
		
		# Si no existe el usuario en la tabla...
		if usuarioExistente == False:
			self.insertarUsuario(row, categoriaExistente)
			salida = 0
		else:
			self.actualizarUsuario(row, usuarioExistente, categoriaExistente)
			salida = 1

		return salida

	# Método que comprueba si existe un usuario ya creado
	def existeUsuario(self, name):
		salida = False

		# Comprobamos que existe
		consulta = "SELECT id, name FROM res_partner WHERE LOWER(name)=LOWER('"+name+"')"
		registros = self.utilidades.ejecutarConsulta(consulta)

		# El usuario existe
		if len(registros) != 0:
			salida = registros[0]

		return salida

	# Obtenemos el id de categoria
	def obtenerCategoriaPorNombre(self, categoria):

		# Ajustamos C, P o T
		if categoria == "C":
			busqueda = "Cliente"
		elif categoria == "P":
			busqueda = "Proveedor"
		elif categoria == "T":
			busqueda = "Proveedor y Cliente"
		else:
			busqueda = categoria

		# Comprobamos que existe
		consulta = "SELECT id, name FROM res_partner_category WHERE LOWER(name)=LOWER(%s)"
		registros = self.utilidades.ejecutarConsulta(consulta, (busqueda,))

		# La categoria no existe, 
		if len(registros) == 0:
			# Comprobamos que existe
			consulta = "INSERT INTO res_partner_category (name) VALUES (%s)"
			registros = self.utilidades.ejecutarInsercion(consulta, (busqueda,))

			# Una vez insertada, la devolvemos
			salida = self.obtenerCategoriaPorNombre(categoria)

		# Si que existe, la devolvemos
		else:
			salida = registros[0]

		return salida

	# Obtenemos el id de cliente
	def obtenerClientePorNombre(self, name):
		# Inicializamos la salida
		salida = False

		# Comprobamos que existe
		consulta = "SELECT id, name FROM res_partner WHERE LOWER(name)=LOWER(%s)"
		registros = self.utilidades.ejecutarConsulta(consulta, (name,))

		# El usuario existe
		if len(registros) != 0:
			salida = registros[0]

		return salida

	# Metodo que nos indica si el login existe en la tabla
	def existeLogin(self, login):
		salida = False

		# Comprobamos que existe
		consulta = "SELECT id, login FROM res_users WHERE LOWER(login)=LOWER(%s)"
		registros = self.utilidades.ejecutarConsulta(consulta, (login,))

		# El usuario existe
		if len(registros) != 0:
			salida = True

		return salida

	# Método que inserta un usuario
	def insertarUsuario(self, datosUsuario, datosCategoria):
		# Creamos el login
		login = self.crearLogin(datosUsuario['name'])
		# Creamos el password
		password = self.crearPassword(datosUsuario['name'])

		# Insertamos el usuario
		consulta = "INSERT INTO res_users (login, password, company_id, partner_id, notification_type) VALUES (%s, %s, '1', '1', 'email')"
		user_id = self.utilidades.ejecutarInsercion(consulta, (login, password))			

		# Insertamos en la tabla partners
		consulta = "INSERT INTO res_partner (name, display_name, street, phone, email, website, city, zip, user_id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)"
		partner_id = self.utilidades.ejecutarInsercion(consulta, (datosUsuario['name'], datosUsuario['display_name'], datosUsuario['street'], datosUsuario['phone'], datosUsuario['email'], datosUsuario['website'], datosUsuario['city'], datosUsuario['zip'], user_id))

		# Actualizamos los ids
		consulta = "UPDATE res_users SET partner_id=%s WHERE id=%s"
		user_id = self.utilidades.ejecutarActualizacion(consulta, (partner_id, user_id))

		# Borramos la relación de categroria anterior la relación de categorias
		consulta = "DELETE FROM res_partner_res_partner_category_rel WHERE partner_id='"+str(partner_id)+"'"
		rel_id = self.utilidades.ejecutarActualizacion(consulta, ())

		# Insertamos la relacion actual
		consulta = "INSERT INTO res_partner_res_partner_category_rel (category_id, partner_id) VALUES (%s, %s)"
		rel_id = self.utilidades.ejecutarActualizacion(consulta, (datosCategoria['id'], partner_id))

		return True

	# Método que actualiza un usuario
	def actualizarUsuario(self, datosUsuario, usuarioExistente, categoriaExistente):
		# Actualizamos el usuario
		consulta = "UPDATE res_partner SET name=%s, display_name=%s, street=%s, phone=%s, email=%s, website=%s, city=%s, zip=%s WHERE id=%s"
		user_id = self.utilidades.ejecutarActualizacion(consulta, (datosUsuario['name'], datosUsuario['display_name'], datosUsuario['street'], datosUsuario['phone'], datosUsuario['email'], datosUsuario['website'], datosUsuario['city'], datosUsuario['zip'], usuarioExistente['id']))

		# Borramos la relación de categroria anterior la relación de categorias
		consulta = "DELETE FROM res_partner_res_partner_category_rel WHERE partner_id='"+str(usuarioExistente['id'])+"'"
		rel_id = self.utilidades.ejecutarActualizacion(consulta, ())

		# Insertamos la relacion actual
		consulta = "INSERT INTO res_partner_res_partner_category_rel (category_id, partner_id) VALUES (%s, %s)"
		rel_id = self.utilidades.ejecutarActualizacion(consulta, (categoriaExistente['id'], usuarioExistente['id']))

		return True

	# Imprimimos el menu
	def imprimirMenu(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		print(30 * "-", "EJERCICIO 6", 30 * "-")
		print("1. Importar clientes")
		print("2. Listar clientes")
		print("3. Modificar cliente")
		print("4. Exportar clientes")
		print("0. Salir ")
		print(73 * "-")

	# Metodo que muestra el menu
	def mostrarMenu(self):
		continuar = True

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			self.imprimirMenu()
			
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-4]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				self.importarClientes()
			elif opcion == '2':
				self.listarClientes()
			elif opcion == '3':
				self.modificarClientes()
			elif opcion == '4':
				self.exportarClientes()
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mostramos error de opcion incorrecta
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]

if __name__ == "__main__":
	# Creamos la instancia
	instancia = GestorClientes()
	instancia.mostrarMenu()
