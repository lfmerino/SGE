import datetime
import os
import csv

try:
	import psycopg2
	from psycopg2 import Error
	from psycopg2.extras import RealDictCursor
except:
	print("ERROR: Falta la librería psycopg2. Se puede instalar con 'pip install psycopg2'")
	exit()

class Utilidades():
	def __init__(self):
		self.conexion = None
		self.dbuser = "postgres"
		self.dbpass = ""
		self.dbname = "odoo"
		self.dbhost = "192.168.2.3"
		self.dbport = "5432"

	def getConexion(self):
		try:
			# Connect to an existing database
			self.conexion = psycopg2.connect(user=self.dbuser, password=self.dbpass, host=self.dbhost, port=self.dbport, database=self.dbname)
			return self.conexion
		except:
			print("ERROR: No se pudo conectar a PostgreSQL")
			exit()

	def cerrarConexion(self):
		if (self.conexion):
			self.conexion.close()

	def ejecutarConsulta(self, consulta, datos):
		try:
			# Abrimos la conexion
			self.conexion = self.getConexion()

			# Obtenemos el cursor
			cursor = self.conexion.cursor(cursor_factory=RealDictCursor)

			# Ejecutamos la consulta
			cursor.execute(consulta, datos)
			resultados = cursor.fetchall()

			# Liberamos el cursos
			cursor.close()

			# Cerramos la conexion
			self.cerrarConexion();

			return resultados
		except (Exception, Error) as error:
			print(consulta)
			print("ERROR: Error en la consulta SQL:", error)
			exit()

	def ejecutarInsercion(self, consulta, datos):

		try:
			# Abrimos la conexion
			self.conexion = self.getConexion()

			# Obtenemos el cursor
			cursor = self.conexion.cursor(cursor_factory=RealDictCursor)

			# Ejecutamos la consulta
			cursor.execute(consulta, datos)
			cursor.execute('SELECT LASTVAL()')
			salida = cursor.fetchone()['lastval']

			# Comiteamos
			self.conexion.commit()

			# Liberamos el cursos
			cursor.close()

			# Cerramos la conexion
			self.cerrarConexion();

			return salida
		except (Exception, Error) as error:
			print(consulta)
			print(datos)
			print("ERROR: Error en la consulta SQL:", error)
			exit()

	def ejecutarActualizacion(self, consulta, datos):

		try:
			# Abrimos la conexion
			self.conexion = self.getConexion()

			# Obtenemos el cursor
			cursor = self.conexion.cursor(cursor_factory=RealDictCursor)

			# Ejecutamos la consulta
			cursor.execute(consulta, datos)
			salida = True

			# Comiteamos
			self.conexion.commit()

			# Liberamos el cursos
			cursor.close()

			# Cerramos la conexion
			self.cerrarConexion();

			return salida
		except (Exception, Error) as error:
			print(consulta)
			print("ERROR: Error en la consulta SQL:", error)
			exit()

	# Funcion para borrar la pantalla
	@staticmethod
	def borrarPantalla():
		if os.name == "posix":
			os.system ("clear")
		elif os.name == "ce" or os.name == "nt" or os.name == "dos":
			os.system ("cls")