import os,sys,inspect
sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe()))))

import csv 

from tablas import Tablas
from utilidades import Utilidades

class GestorProductos():
	# Método de inicio, obtenemos los datos de configuracion
	def __init__(self):
		# Clases comunes
		self.tablas = Tablas()
		self.utilidades = Utilidades()

	# Método para listar los registros
	def listarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Cabecera
		print("LISTAR REGISTROS ", 30 * "-")

		consulta = "SELECT id, name, description FROM product_template"
		registros = self.utilidades.ejecutarConsulta(consulta)
		self.tablas.imprimirRegistros(registros)

	# Método para exportar a CSV
	def exportarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Cabecera
		print("EXPORTAR REGISTROS ", 30 * "-")

		consulta = "SELECT id, name, description FROM product_template ORDER BY description ASC"
		registros = self.utilidades.ejecutarConsulta(consulta)
		self.tablas.definirHeader(('id','name','description'))
		self.tablas.rellenarRegistros(registros)
		self.tablas.exportarRegistros()

	# Método para buscar registros
	def buscarRegistros(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		# Pedimos datos
		print("BUSCAR REGISTRO ", 30 * "-")

		consulta = "SELECT id, name, description FROM product_template ORDER BY description ASC"
		registros = self.utilidades.ejecutarConsulta(consulta)
		self.tablas.definirHeader(('id','name','description'))
		self.tablas.rellenarRegistros(registros)
		self.tablas.buscarRegistros()

	# Imprimimos el menu
	def imprimirMenu(self):
		# Borramos la pantalla
		self.utilidades.borrarPantalla()

		print(30 * "-", "EJERCICIO 5", 30 * "-")
		print("1. Listar productos ")
		print("2. Buscar productos ")
		print("3. Exportar productos ")
		print("0. Salir ")
		print(73 * "-")

	# Metodo que muestra el menu
	def mostrarMenu(self):
		continuar = True

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			self.imprimirMenu()
			
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-3]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				self.listarRegistros()
			elif opcion == '2':
				self.buscarRegistros()
			elif opcion == '3':
				self.exportarRegistros()
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mostramos error
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]

if __name__ == "__main__":
	# Creamos la instancia
	instancia = GestorProductos()
	instancia.mostrarMenu()