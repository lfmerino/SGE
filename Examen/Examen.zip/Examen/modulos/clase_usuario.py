from datetime import datetime
import modulos.utiles

class Usuario:
    usuario = ""
    contrasena = ""
    nombre = ""
    id_compania = ""
    id_colega = ""
    fecha_crea = ""
    fecha_escribe = ""
    firma = ""
    uid_crea = ""
    uid_escribe = ""
    notif = ""
    sexo = ""

    # def __init__(self, nif, nombre, apellido, fecha_nac, direccion):
    #     self.nif = nif
    #     self.nombre = nombre
    #     self.apellido = apellido
    #     self.fecha_nac = fecha_nac
    #     self.direccion = direccion
    #     pass
    
    def __init__(self, nombre, notif, sexo):
        self.nombre = nombre
        self.id_compania = 1
        # self.id_colega = ""
        # self.fecha_crea = fecha_crea # La usaremos más tarde justo antes del insert
        self.fecha_escribe = datetime.now()
        if (sexo.upper() == "H"):
            self.firma = "Sr. "
        else:
            self.firma = "Sra. "
        self.uid_crea = 2
        self.uid_escribe = 2
        self.notif = notif
        self.usuario = modulos.utiles.creaLogin(self)
        self.contrasena = modulos.utiles.creaPasswd(self)
        self.sexo = sexo
        pass

    def checkTipo(self, p = ""):
        valores = ["P", "T", "C"]
        if not( p.upper() in valores):
            print("El 'Tipo' no es correcto")
            return None
        else:
            return p
        
