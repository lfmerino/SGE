import modulos.sqlpost

secuela = modulos.sqlpost.SqlPostgre()
secuela.cargarCSV()

