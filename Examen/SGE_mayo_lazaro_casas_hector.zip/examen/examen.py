#!/usr/bin/python3

import os,sys,inspect
dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe)))
sys.path.insert(0,dir)


from modulos.Connection_postgresql import Connection
from modulos.Ejercicio4 import Tablas
from modulos.Ejercicio6 import Clientes_Proveedores
try:
    from pandas.io.sql import read_sql_query
    import pandas as pd
    import psycopg2
    from psycopg2 import Error
except:
    print("ERROR: Falta la librería pandas. Se puede instalar con 'pip install pandas'")
    exit()
import datetime
import time

#pip install prettytable
#pip install psycopg2
#pip install pandas

class ExamenMayo():

    def __init__(self):
        
        self.conn = None
        self.df = pd.DataFrame()
        self.conexion = Connection()
        self.tablas = Tablas()
        self.usuarios = Clientes_Proveedores()
        self.login_insertado = 0
        self.login_actualizado = 0
        self.registros_insertados = 0
        self.registros_modificados = 0
        

    def inicio(self):


        self.conn = self.conexion.get_connection()

        #importamos datos desde csv a tabla
        self.df = self.tablas.llenar_tabla('usuarios.csv')

        #mostramos datos importados
        if(len(self.df) != 0):
            print(self.df)
            print("")

        #Comprobamos usuarios en tabla res_partner
        if self.df.size != 0:
            for row in self.df.itertuples(index=False):
                nombre = row.nombre
                sexo = row.sexo
                mail = row.email
                print(nombre)
                nombre_login = self.usuarios.crear_user(nombre)
                #print(nombre_login)
                password_login = self.usuarios.crear_password(nombre)
                #print(password_login)
                sig = self.recuperar_sig(nombre,sexo)
                print(sig)
                #print(str(sig))
                today = datetime.datetime.today()
                #print(today)
                id = self.usuarios.buscar_cliente(nombre)
                update = (nombre_login,password_login,1,id,today,sig,2,2,'email')
                insert = (nombre_login,password_login,1,id,today,today,sig,2,2,'email')
                
                #print(id)
                if id != -1: #esta registrado, por tanto actualizamos registro en res_partner
                    sql = "UPDATE res_partner SET name = %s,display_name = %s, write_date = %s, lang = %s, email = %s, commercial_partner_id = %s, create_uid = %s, write_uid = %s WHERE LOWER(name)=LOWER('"+str(nombre)+"')"
                    datos = (nombre,nombre,today,'es_ES',mail,2,2,2)
                    respuesta = self.usuarios.actualizar_registro(sql,datos)
                    if respuesta == True:
                        self.registros_modificados = self.registros_modificados +1
                        self.operaciones_login(id,insert,update) 
                else:
                    sql = "INSERT INTO res_partner(name, display_name, create_date, write_date, lang, email, commercial_partner_id, create_uid,write_uid) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    datos = (nombre,nombre,today,today,'es_ES',mail,2,2,2)
                    respuesta = self.usuarios.insertar_registro(sql,datos)
                    if respuesta == True:
                        self.registros_insertados = self.registros_insertados + 1
                        id = self.usuarios.buscar_cliente(nombre)
                        if id != -1:
                            update = (nombre_login,password_login,1,id,today,sig,2,2,'email')
                            insert = (nombre_login,password_login,1,id,today,today,sig,2,2,'email')
                            self.operaciones_login(id,insert,update)

            self.conexion.close_connection(self.conn)
            print("Se han modificado " + str(self.registros_modificados) + " registros en res_partner.")
            print("Se han insertado " + str(self.registros_insertados) + " registros en res_partner.")
            print("Se han insertado " + str(self.login_insertado) + " registros en res_users.")
            print("Se han actualizado " + str(self.login_actualizado) + " registros en res_users.")

        else:
            print("No se han importado datos del archivo csv")    
        
    def operaciones_login(self,id,insert,update):

        respuesta = self.usuarios.buscar_login(id)
        if respuesta == True: # ya tiene registro en res_users, asi que actualizamos
            sql = "UPDATE res_users SET login = %s,password = %s, company_id = %s, partner_id = %s, write_date = %s, signature = %s, create_uid = %s, write_uid = %s,notification_type = %s WHERE partner_id = '"+ str(id) + "'"
            respuesta = self.usuarios.actualizar_login(sql,update)
            if respuesta == True:
                self.login_actualizado = self.login_actualizado + 1    
        else:
            # no tiene registro en res_users, asi que insertamos
            sql = "INSERT INTO res_users (login,password, company_id, partner_id,create_date, write_date , signature, create_uid, write_uid, notification_type) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
            respuesta = self.usuarios.insertar_login(sql,insert)
            if respuesta == True:
                self.login_insertado = self.login_insertado + 1
    
    def recuperar_sig(self,nombre,sexo):
        #dividimos nombre en partes
        apellidos = str(nombre).split(' ')
        #print(apellidos)

        if(str(sexo).lower() == 'h'):
            sig = 'Sr. ' + str(apellidos[1])
        else:
            sig = 'Sra. ' + str(apellidos[1])

        return sig

if __name__ == "__main__":
    examen = ExamenMayo()
    examen.inicio()