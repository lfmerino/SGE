#!/usr/bin/python3

import os,sys,inspect
dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe)))
dir_padre = os.path.dirname(dir)
sys.path.insert(0,dir_padre)

class ValidarUser:

    def __init__(self):
        self.usuario = None
        
    def validar(self,usuario):
    
        if len(usuario) < 6:
            valor = 1

        elif usuario.isalnum() == False:
            valor = 3

        elif len(usuario) > 12:
            valor = 2
     
        else: 
            valor = 0

        return valor

if __name__ == "__main__":   
    nuevoUsuario = ValidarUser().validar('juanpedro23')
    print(nuevoUsuario)