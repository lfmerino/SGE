#!/usr/bin/python3

import os,sys,inspect
dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe)))
sys.path.insert(0,dir)

import pandas as pd
import csv
from modulos.Ejercicio3 import Datos
import re

#pip install prettytable
#pip install pandas

class Tablas:
    
    def __init__(self):
        self.i = 0
        self.lista_dic = []
        self.header_table = ['Nombre','Apellidos','Fecha','Direccion','Contraseña']
        self.df = pd.DataFrame()
        self.datos = Datos()
        
    def iniciar_menu(self):
        print("")
        print("1. Introducir datos")
        print("2. Buscar por nombre")
        print("3. Buscar por apellido")
        print("4. Volcar tabla de datos a fichero CSV")
        print("5. Rellenar tabla desde CSV")
        print("0. Salir")

    def iniciar_datos(self):
    
        respuesta = 1
        while respuesta >= 0 and respuesta < 6:

            self.iniciar_menu()
            try:
                respuesta = int(input("Elija una opción del menú: "))
            except:
                print("\nError: Debes escribir un número del 0 al 5\n")
                respuesta = -1
                
            if respuesta == 1:
                self.introducir_datos()
            if respuesta == 2:
                self.buscar_nombre()
            if respuesta == 3:
                self.buscar_apellido()
            if respuesta == 4:
                self.crear_csv("usuarios.csv",self.df)
            if respuesta == 5:
                self.df = self.llenar_tabla("usuarios.csv")
            if respuesta == 0:
                exit()
            if respuesta < 0 or respuesta > 5:
                print("\nError: Debes escribir un número del 0 al 5\n")
                respuesta = 0

    def introducir_datos(self):

        nombre = self.datos.pedir_usuario()
        password = self.datos.pedir_password()
        apellido = input("Introduce apellidos: ")
        fecha = input("Introduce fecha de nacimiento [dd-mm-yyyy]: ")
        direccion = input("Introduce dirección: ")


        dic = {'nombre':nombre,'apellido':apellido,'fecha':fecha,'direccion':direccion,'password':password}
        self.lista_dic.append(dic)
        self.df = pd.DataFrame(self.lista_dic)
        print(self.df)

        

    def buscar_nombre(self):
        nombre = str(input("Introduce nombre de usuario a buscar: "))
        if len(self.df) != 0:
            new_df = self.df.query("nombre == @nombre")
            if new_df.size == 0:
                print("El usuario con ese nombre no existe")
            else:
                print(new_df.to_string(index=False))
        else:
            print("La tabla de datos donde buscar está vacía.")

    def buscar_apellido(self):
        apellido = input("Introduce el apellido a buscar: ")
        if len(self.df) != 0:
            new_df = self.df.query("apellido == @apellido")
            if new_df.size == 0:
                print("El usuario con ese apellido no existe")
            else:
                print(new_df.to_string(index=False))
        else:
            print("La tabla de datos donde buscar está vacía.")

    def crear_csv(self, archivo_csv,dframe):
        dframe.to_csv(archivo_csv,index=False,quoting=csv.QUOTE_NONE,escapechar = "\n")
        return dframe

    def llenar_tabla(self,archivo_csv):
        try:
            df = pd.read_csv(archivo_csv,delimiter=",",skiprows=0)
            #print(df)
            return df
        except(FileNotFoundError) as error:
            print("No se encuentra el fichero " + archivo_csv)

if __name__ == "__main__":
    mi_tabla = Tablas()
    mi_tabla.iniciar_datos()

            