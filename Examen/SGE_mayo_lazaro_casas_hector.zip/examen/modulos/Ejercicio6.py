#!/usr/bin/python3

import os,sys,inspect
dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe)))
sys.path.insert(0,dir)

import psycopg2
from modulos.Ejercicio4 import Tablas
from modulos.Connection_postgresql import Connection
from psycopg2 import Error
from psycopg2 import DatabaseError
import time
import random
import pandas as pd

#pip install pandas
#pip install psycopg2

class Clientes_Proveedores():
    
    def __init__(self):
        conn = None 
        self.registros_modificados = 0
        self.registros_insertados = 0
        self.registros_noInsertados = 0
        self.login_actualizados = 0
        self.login_insertados = 0
        self.df = pd.DataFrame()
        self.conexion = Connection()
        self.tablas = Tablas()

    def inicio(self):
        self.mostrar_clientes()
        #conexion.close_connection(self.conn)
    
    def mostrar_clientes(self):

        self.conn = self.conexion.get_connection()
        self.df = pd.DataFrame(self.tablas.llenar_tabla("clientes.csv"))
        print(self.df)
        if self.df.size != 0:
            for row in self.df.itertuples(index=False):
                #print("len row:" + str(len(row)))
                if len(row) == 7:
                    try:
                        nombre = row[0]
                        reg = (row[0],row[1],row[2],row[3],row[4],row[5],row[6],nombre)
                        respuesta_id = self.buscar_cliente(nombre)
                        if(respuesta_id != -1):
                            sql = "UPDATE res_partner SET name = %s, street = %s, phone = %s, email = %s, website = %s, city = %s, zip = %s WHERE LOWER(name)=LOWER('"+str(nombre)+"')"
                            self.actualizar_registro(sql,reg)
                        else:
                            sql = "INSERT INTO res_partner(name,street,phone,email,website,city,zip) VALUES(%s,%s,%s,%s,%s,%s,%s)"
                            self.insertar_registro(sql,reg)


                        #descomponemos nombre y apellidos
                        nombre_descompuesto = str(nombre).split()
                        if len(nombre_descompuesto) >= 3:
                            #print(nombre)
                            nombre_login = self.crear_user(nombre)
                            #print(nombre_login)
                            password_login = self.crear_password(nombre)
                            #print(password_login)
                            try:
                                if(respuesta_id != -1):
                                    respuesta = self.buscar_login(id)
                                    if respuesta == True:
                                        #actualizamos login usuario
                                        sql = "UPDATE res_users SET login = %s, password = %s, company_id = %s, notification_type = %s WHERE partner_id = '" + str(id) + "'"
                                        datos = (nombre_login,password_login,1,'email');
                                        self.actualizar_login(sql,datos)
                                    else:
                                        sql = "INSERT INTO res_users (partner_id,login,password,company_id,notification_type) VALUES(%s,%s,%s,%s,%s)"
                                        datos = (id,nombre_login,password_login,1,'email')
                                        self.insertar_login(sql,datos)

                                else:
                                    print("El usuario no esta registrado en la tabla res_partner")
                            except (Exception, psycopg2.DatabaseError) as error:
                                print(error)
           
                        else:
                            print("El nombre no esta bien formado, no se crea login para este usuario")

                    except (Exception, Error) as error:
                        print(error)
                else:
                    print("No se encuentran todos los campos de ese registro.")
                    self.registros_noInsertados = self.registros_noInsertados + 1
        print("Se han modificado " + str(self.registros_modificados) + " registros en res_partner.")
        print("Se han insertado " + str(self.registros_insertados) + " registros en res_partner.")
        print("No se han insertado " + str(self.registros_noInsertados) + " registros en res_partner.")
        print("Se han insertado " + str(self.login_insertados) + " nuevos registros en res_users.")
        print("No han actualizado " + str(self.login_actualizados) + " registros en res_users.")       
                

    def buscar_cliente(self,nombre):

        self.conn = self.conexion.get_connection()
        cursor = self.conn.cursor()
        cursor.execute("select id,name,street,phone,email,website,city,zip from res_partner WHERE LOWER(name)=LOWER('"+str(nombre)+"')")
        rows = cursor.rowcount
        #print(rows)
        data = cursor.fetchone()
        #print("Data: " + str(data))
        if data != None:
            #existe el registro y actualizamos
            return data[0]             
        else:
            #no existe el registro e insertamos
            return -1

    def buscar_login(self,id):

        if id != -1:
            self.conn = self.conexion.get_connection()
            cursor = self.conn.cursor()
            cursor.execute("select login from res_users where partner_id = '" + str(id) + "'")
            resultado = cursor.fetchall()
            if len(resultado) == 0:
                return False
            else:
                return True
        else:
            print("El usuario no esta registrado en la tabla res_partner")
        

    def actualizar_registro(self,sql,reg):

        try:
            self.conn = self.conexion.get_connection()
            cursor = self.conn.cursor()
            cursor.execute(sql,reg)
            rows = cursor.rowcount
            cursor.close()
            self.conn.commit()
            if(rows == 1):
                print("Cliente modificado")
                self.registros_modificados = self.registros_modificados + 1
                return True
            else:
                return False

        except (Exception, psycopg2.DatabaseError) as error:
            print(error)

    def insertar_registro(self,sql,reg):
  
        try:
            self.conn = self.conexion.get_connection()
            cursor = self.conn.cursor()
            cursor.execute(sql,reg)
            rows = cursor.rowcount
            cursor.close()
            self.conn.commit()
            if(rows == 1):
                print("Cliente insertado")
                self.registros_insertados = self.registros_insertados + 1
                return True
            else:
                return False
            
                
        except (Exception, psycopg2.DatabaseError) as error:
            print(error)


    def actualizar_login(self,sql,datos):
        try:
            self.conn = self.conexion.get_connection()
            cursor = self.conn.cursor()
            cursor.execute(sql,datos)
            rows = cursor.rowcount
            cursor.close()
            self.conn.commit()
            if(rows == 1):
                print("Login actualizado satisfactoriamente")
                self.login_actualizados = self.login_actualizados + 1
                return True
            else:
                return False
            

        except (Exception, psycopg2.DatabaseError) as error:
            print(error)


    def insertar_login(self,sql,datos):
        try:
            self.conn = self.conexion.get_connection()
            cursor = self.conn.cursor()
            cursor.execute(sql,datos)
            rows = cursor.rowcount
            cursor.close()
            self.conn.commit()
            if(rows == 1):
                print("Login insertado satisfactoriamente")
                self.login_insertados = self.login_insertados + 1
                return True
            else:
                return False
            

        except (Exception, psycopg2.DatabaseError) as error:
            print(error)

    def crear_user(self,nombre):

        nombre_login = str(nombre).split()
        usuario = ""
        primera_letra_nombre = str(nombre_login[0][:1])
        usuario = str(primera_letra_nombre + nombre_login[1]) #primera letra nombre mas primer apellido
        usuario = str(usuario.lower())
        return usuario

    def crear_password(self,nombre):

        nombre_login = str(nombre).split()
        random.shuffle(nombre_login)
        signos = ['$','%','&']
        primera_letra_nombre = str(nombre_login[0][:1])
        tiempo = str(time.localtime(time.time()))
        seg_time = str(tiempo[5])
        letra1_apellido = str(nombre_login[1][1:2])
        letra2_apellido = str(nombre_login[1][2:3].upper())
        min_time = str(tiempo[4])
        letra4_apellido2 = str(nombre_login[2][3:4])
        signo = str(random.choice(signos))
        password = primera_letra_nombre + seg_time + letra1_apellido + letra2_apellido + min_time + letra4_apellido2 + signo
        return password


if __name__ == "__main__":
    clientes = Clientes_Proveedores()
    clientes.inicio()