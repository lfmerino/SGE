#!/usr/bin/python3

import os,sys,inspect
dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe)))
dir_padre = os.path.dirname(dir)
sys.path.insert(0,dir_padre)

import re

class ValidarPass:

    def __init__(self):
        self.password = None
        
    def validar(self,password):
 
        if len(password) < 8:
            return False
        elif password.isalnum() or re.search(' ', password):
            return False
        elif len(password) > 12:
            return False
        else: 
            return True

if __name__ == "__main__":
    nuevoPass = ValidarPass().validar("lsit-25465")
    print(nuevoPass)