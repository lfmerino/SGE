#!/user/bin/env python 
# -*- coding: utf-8 -*-

import csv
import modulos.FicheroCSV
import modulos.BDpostgres
import os
# --------------------------------------------
#       METODOS PARA INSERTAR CLIENTE
# --------------------------------------------

def BorrarCliente(nom):
	sql = "DELETE FROM res_users WHERE name='"+nom+"'" 
	print  db.Consulta(sql) +": "+nom
# --------------------------------------------
#                 PRINCIPAL
# --------------------------------------------

print '\n======================================================'
print '\tBORRAR CLIENTES'
print '======================================================'


dbname = raw_input('\tIntroduce nombre de la base de datos> ')
user = raw_input('\tIntroduce usuario> ')
host = raw_input('\tIntroduce host> ')
password = raw_input('\tIntroduce contraseña> ')
port = raw_input('\tIntroduce puerto> ')
'''

dbname='Libreria'
user='postgres'
#host='10.22.100.44'
host ='192.168.1.76'
password='virgi'
port='5432'
'''
db = modulos.BDpostgres.BD()

datos = db.CrearConexion(dbname,user,host,password,port)


while datos==False:
	print 'Datos no validos. Introducir datos correctos:'

	dbname = raw_input('\tIntroduce nombre de la base de datos> ')
	user = raw_input('\tIntroduce usuario> ')
	host = raw_input('\tIntroduce host> ')
	password = raw_input('\tIntroduce contraseña> ')
	port = raw_input('\tIntroduce puerto> ')


	datos = db.CrearConexion(dbname,user,host,password,port)
print 'Conectado a la base de datos...'

result=''
op='s'

while True:	
	
	if op=='S' or op=='s':
		print '-------------------------------------------------'
		print '\t FICHERO CON DATOS '
		print '-------------------------------------------------'
		'''
		nom = raw_input('\tIntroduce nombre del fichero> ')
		'''
		nom ='usuarios.csv'
		
		directorioActual = '{0}'.format(os.getcwd()) + '/'+ nom
		#print directorioActual
		
		
		if os.path.isfile(directorioActual): #metodo comprueba si el fichero existe
			fic =  modulos.FicheroCSV.FicheroCSV(nom)
			

			res = raw_input('\t¿Desea visualizar el fichero? s/n> ')
			if res=='s' or res=='S':
				print '-------------------------------------------------'
				print '\t VISUALIZR FICHERO '+ nom
				print '-------------------------------------------------'
				print fic.Leer()	
				print '-------------------------------------------------'
		

		
			res = raw_input('\t¿Desea borrar los clientes que contiene el fichero? s/n> ')
			if res=='s' or res=='S':
				#obtener diccionario con contenido del fichero
				dic = fic.convertirDiccionario()
				for i in dic:
					fila = dic[i]
					BorrarCliente(fila[0])

		else:
			print 'El fichero no existe'
		print '-------------------------------------------------'
	

	else:
		print 'FIN PROGRAMA\n'
		db.CerrarConexion()
		break

	op = raw_input ("¿DESEA CONTINUAR? S/N: ")
	print '======================================================\n'













