#! /usr/bin/python 
# _*_ coding: utf-8 _*_ 
inser="N"
while inser!="S":
	inser=raw_input("MENU!!!!\nInsertar?(I)\nModificar?(M)\nExportar datos a csv?(E)\nSalir(S)")
	#import ejecuta los archivos init
	print "Insertando...."
	if inser=="I":
		import dir1.insertar
		dir1.insertar.insertar()
	elif inser=="M":
		print "Seleccionando y modificando datos de un cliente...."
		import dir1.modificar
		dir1.modificar.listar()
	elif inser=="E":
		print "Seleccionado el menu exportar datos a CSV"
		import dir1.exportarCSV
		dir1.exportarCSV.exportar()
	elif inser=="S":
		print "salir"


