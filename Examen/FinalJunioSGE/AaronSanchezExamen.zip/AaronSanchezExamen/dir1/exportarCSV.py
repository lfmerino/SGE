# _*_ coding: utf-8 _*_ 
import csv
import psycopg2
def exportar():
	try:
		conexion = psycopg2.connect(database="prueba", user="postgres", password="postgres", host="192.168.1.38", port="5432")
		print "Opened database successfully"
		cursor = conexion.cursor()
		sql = "select id, name, email,login from res_users"
		print "Obtener datos de todos los usuarios"
		try:
			cursor.execute(sql)
			result = cursor.fetchall()
			#print result #array
			cont = 0
			f=open("exportacion.csv","w") 
			for registro in result:
				res = result[cont]
				print str(res[0])+","+str(res[1])+","+str(res[2])+","+str(res[3])
				cont = cont + 1
				f.write(str(res[0])+","+str(res[1])+","+str(res[2])+","+str(res[3])+"\n")
			cursor.close
			f.close()
		except:
			print "Error E/S..."
		conexion.close()
	except:
		print "Error al conectar con la base de datos"

	
