# _*_ coding: utf-8 _*_ 
import psycopg2
import csv
import time
def insertar():
	try:
		conexion = psycopg2.connect(database="prueba", user="postgres", password="postgres", host="192.168.1.38", port="5432")
		print "Opened database successfully"
		try:
			f=csv.reader(open("usuarios.csv","r"),delimiter=",")
			for fila in f: #fila 
				print fila[0]+","+fila[1]+","+fila[2]
				cursor = conexion.cursor()
				sql = "insert into res_users (name,email,password,login,signature,company_id) values ('"+fila[0]+"','"+fila[1]+"','"+passw(fila[0])+"','"+login(fila[0])+"','"+signature(fila[0],fila[2])+"','1')"
				try:
					cursor.execute(sql)
					print "Fila insertada con exito"
					conexion.commit()
				except:
					print "Fila no insertada."
			#fin for
			f.close()
		except:
			print "Error lectura/escritura"
		#fin except
		conexion.close()
		print "Conexion cerrada."
	except:
		print "No se pudo conectar a la base de datos"


def login(nombre):
	#nombre="Ana Calvo Sanchez" #Ejemplo
	nombreAux="" #Nombre a devolver
	cont = 0	
	espacio = 0
	while cont<len(nombre):
		if cont == 0:
			nombreAux = nombre[cont]
			cont = cont + 1
		elif nombre[cont]==" " and espacio==0:
			cont = cont + 1
			try:
				while nombre[cont]!=" ":
					nombreAux = nombreAux + nombre[cont].lower()
					cont = cont + 1
				espacio=1
			except:
				print "Solo contiene un apellido"
		cont = cont + 1
	return nombreAux

def signature(nombre,sexo):
	nombreAux="" #Nombre a devolver
	cont = 0	
	espacio = 0
	if sexo=="H":
		nombreAux="Sr. "
	elif sexo=="M":
		nombreAux="Sra. "
	while cont<len(nombre):
		if nombre[cont]==" " and espacio==0:
			cont = cont + 1
			try:
				while nombre[cont]!=" ":
					nombreAux = nombreAux + nombre[cont]
					cont = cont + 1
				espacio=1
			except:
				print "Solo contiene un apellido"
		cont = cont + 1
	return nombreAux

def passw(nombre):
	#primera letra de nombre
	password=nombre[0]
	#hora
	horaActual = time.strftime('%H:%M:%S')
	hora=horaActual[0]+horaActual[1]
	mins=horaActual[3]+horaActual[4]
	segs=horaActual[6]+horaActual[7]
	#seg
	password=password+segs
	#2 y 3 letras de apellido
	cont = 0
	espacio = 0
	nombreAux = ""
	cont2 = 1
	letra1 = ""
	letra2 = ""
	while cont<len(nombre):
		if nombre[cont]==" " and espacio==0:
			cont = cont + 1
			try:
				while nombre[cont]!=" ":
					if cont2==1:
						cont = cont + 1
						letra1 = nombre[cont]
						cont2 = 2
					elif cont2==2:
						letra2 = nombre[cont].upper()
						cont2 = cont + 1
					cont = cont + 1
				espacio=1
			except:
				print "Solo contiene un apellido"
		cont = cont + 1
	password=password+letra1+letra2
	#min
	password=password+mins
	return password
