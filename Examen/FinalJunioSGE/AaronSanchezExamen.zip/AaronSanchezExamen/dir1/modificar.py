# _*_ coding: utf-8 _*_ 
import psycopg2
def listar():
	try:
		conexion = psycopg2.connect(database="prueba", user="postgres", password="postgres", host="192.168.1.38", port="5432")
		print "Opened database successfully"
		cursor = conexion.cursor()
		sql = "select id, name from res_users"
		print "Obtener datos de todos los usuarios"
		try:
			cursor.execute(sql)
			result = cursor.fetchall()
			#print result #array
			cont = 0
			for registro in result:
				print "Usuario: "+str(result[cont])
				cont = cont + 1
			cursor.close
		except:
			print "Error al obtener datos..."

		idus=raw_input("Inserte un id para buscar y modificar los datos de ese usuario.")
		cursor = conexion.cursor()
		print "Imprimiendo id,nombre,email,login,signature y password"
		sql = "select id,name,email,login,signature,password from res_users where id='"+idus+"'"
		try:
			cursor.execute(sql)
			result = cursor.fetchall()
			#print result #array
			cont = 0
			for registro in result:
				print ""+str(result[cont])
				cont = cont + 1
			cursor.close
			
			mod=raw_input("Modificar datos del usuario seleccionado??(S/N)")
			if mod=="S":
				name=raw_input("Inserte nombre")
				email=raw_input("Inserte email")
				login=raw_input("Inserte login")
				
				password=raw_input("Inserte pass")
				cursor = conexion.cursor()
				#name
				sql="update res_users set name='"+name+"' where id='"+idus+"'"
				try:
					cursor.execute(sql)
					conexion.commit()
				except:
					print "Error al actualizar nombre"
				#email
				sql="update res_users set email='"+email+"' where id='"+idus+"'"
				try:
					cursor.execute(sql)
					conexion.commit()
				except:
					print "Error al actualizar email"
				#login
				if validacionPass(login)==True:
					sql="update res_users set login='"+login+"' where id='"+idus+"'"
					try:
						cursor.execute(sql)
						conexion.commit()
					except:
						print "Error al actualizar login"
				else:
					sql="update res_users set login='Cam5iar$' where id='"+idus+"'"
					try:
						cursor.execute(sql)
						conexion.commit()
					except:
						print "Error al actualizar login"
				#pass
				sql="update res_users set password='"+password+"' where id='"+idus+"'"
				try:
					cursor.execute(sql)
					conexion.commit()
				except:
					print "Error al actualizar pass"
				
		except:
			print "Error al obtener datos..."
		conexion.close()
	except:
		print "Error al conectar con la base de datos."

def validacionPass(passw): 
	num = 0 
	cont = 0 
	dig = False 
	alpha = False 
	minus = False 
	mayus = False 
	if len(passw)<8: 
		#respuesta = "La contraseña debe contener al menos 8 digitos." 
		num = 1 
	if ' ' in passw: 
		#respuesta = "La contraseña no debe tener espacios." 
		num = 2 
	else: 
		while cont<len(passw): 
			passwAux = passw[cont] #Obtener caracter de passw 
			if passwAux.isdigit()==True: #Si es digito 
				#print "Es digito"				 
				dig = True 
			elif passwAux.isalpha()==True: #Si es alfabetico 
				#print "Es alfanum"				 
				alpha = True 
				if passwAux.islower()==True: #Si es minus 
					#print "Es ninus"				 
					minus = True 
				elif passwAux.isupper()==True: #Si es mayus 
					#print "Es mayus"				 
					mayus = True 
			cont = cont + 1 
	if num == 1 or num == 2 or (dig == False or alpha == False or minus == False or mayus == False): 
		return "La contraseña elegida no es valida." 
	else: 
		return True 
