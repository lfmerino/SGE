import sys
for p in sys.path:
	print(p)

