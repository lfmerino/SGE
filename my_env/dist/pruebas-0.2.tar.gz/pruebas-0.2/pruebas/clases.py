class persona: 
	def __init__(self, nombre, edad): 
		self.nombre = nombre
		self.edad = edad
	def mayordeedad(self): 
		if self.edad > 18: 
			return ("Es mayor de edad"      )
		else: 
			return ("No es mayor de edad")




