import julio.usuarios

u = usuarios.Usuario(input("Usuario: "))

if u.Salida==0:
    print(u.MiNombre)
else:
    print(u.MiNombre)
    print("Hay un error")

