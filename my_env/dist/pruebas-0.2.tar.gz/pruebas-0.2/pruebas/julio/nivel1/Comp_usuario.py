import pruebas.usuarios
u = usuarioj.usuario()
n = input("Contraseña: ")
print(u.test_passwd(n))
