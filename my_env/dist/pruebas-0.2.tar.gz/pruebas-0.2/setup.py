from setuptools import setup
setup(
    name="pruebas",
    version="0.2",
    description="Este es un paquete para pruebas",
    author="Luis mMrino",
    author_email="luisfmerinot@gmail.com",
    url="http://brianda.es",
    packages=['pruebas','pruebas.n1','pruebas.julio','pruebas.julio.nivel1'],
    scripts=[]
)
#python setup.py sdist
#luis@msilfmt:~/enviroments/my_env/dist$ pip install pruebas-0.1.tar.gz
#pip3 list
