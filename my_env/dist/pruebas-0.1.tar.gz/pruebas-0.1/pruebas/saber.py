import clases
nombre = input("Nombre:")
edad = int(input("Edad: "))
p=clases.persona(nombre,edad)
print(p.nombre + ' ' + p.mayordeedad())

