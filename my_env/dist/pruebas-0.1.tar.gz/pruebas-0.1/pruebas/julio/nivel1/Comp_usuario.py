import pruebas.julio.usuario
u = usuarioj.usuario()
n = input("Contraseña: ")
print(u.test_passwd(n))
