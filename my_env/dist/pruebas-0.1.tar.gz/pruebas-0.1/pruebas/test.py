num = 1
while num < 1:
num += 1
print (num)
