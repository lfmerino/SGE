from setuptools import setup
setup(
    name="odoo",
    version="0.4",
    description="Paquete de pruebas para odoo",
    author="Luis Merino",
    author_email="luisfmerinot@gmail.com",
    url="briandademendoza.es",
    packages=['odoo','odoo.addons','odoo.addons.tarea5','odoo.addons.tarea5.modPasswd','odoo.addons.tarea5.modUsuario',
   'odoo.addons.tarea5.modTabla','odoo.addons.tarea5.mismodulos'],
    scripts=[]
)