import csv
from sge05.utilidades.utilidades import Utilidades

class Tablas():
	# Método que muestra el menu principal
	def mostrarMenu(self):
		# Método para importar registros desde el CSV
		def importarRegistros():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Cabecera
			print("IMPORTAR REGISTROS ", 30 * "-")

			# Inicializamos los registros
			registros = {}

			# Pedimos la ruta del archivo
			archivo = input("Introduce la ruta del archivo a importar: ")

			# Comprobamos que el archivo se pueda abrir y exista
			try:
				reader = csv.reader(open(archivo, 'r'))
				next(reader)
				for row in reader:
					nombre, apellidos, email = row
					registros[len(registros)] = {"nombre": nombre, "apellidos": apellidos, "email": email}

				print(str(len(registros)) + " registros importados correctamente.")
			# El archivo no existe
			except IOError:
				print("No se pudo acceder al fichero")

			input("Pulsa cualquier tecla para continuar...")

		# Método para exportar a CSV
		def exportarRegistros(registros):
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Cabecera
			print("EXPORTAR REGISTROS ", 30 * "-")

			# Exportamos datos
			with open('registros_out.csv', 'w') as file_output:
				w = csv.DictWriter(file_output, ('nombre', 'apellidos', 'email'))
				w.writeheader()
				for position, registro in registros.items(): 
					w.writerow(registro)

			print("Registros exportados correctamente en registros_out.csv")
			input("Pulsa cualquier tecla para continuar...")

		# Metodo para buscar registros
		def buscarRegistros(registros):
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Pedimos datos
			print("BUSCAR REGISTRO ", 30 * "-")

			# Busqueda
			busqueda = input("Introduce la búsqueda: ")

			# Variable para filtrar los registros
			filtrados = {}

			# Recorremos y buscamos 
			for registro in registros.values(): 
				if(registro['nombre'].find(busqueda) != -1 or registro['apellidos'].find(busqueda) != -1):
					filtrados[len(filtrados)] = registro

			# Si no tenemos resultados
			if len(filtrados) == 0:
				print("NO HAY RESULTADOS")
			# Si si que tenemos, los mostramos
			else:
				imprimirRegistros(filtrados)

		# Metodo para imprimir la tabla
		def imprimirRegistros(registros):
			# Mostramos las columnas
			print ("{:<10} {:<10} {:<10}".format('NOMBRE', 'APELLIDOS', 'EMAIL')) 
		  
			# Imprimimos los registros
			for registro in registros.values(): 
				print ("{:<10} {:<10} {:<10}".format(registro['nombre'], registro['apellidos'], registro['email']))

			input("Pulsa cualquier tecla para continuar...")

		# Método para pedir los datos
		def pedirDatos():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Pedimos datos
			print("INTRODUCIR REGISTRO ", 30 * "-")

			# NOMBRE
			nombre = input("Introduce el nombre: ")
			# APELLIDOS
			apellidos = input("Introduce los apellidos: ")
			# EMAIL
			email = input("Introduce el email: ")

			return {"nombre": nombre, "apellidos": apellidos, "email": email}

		# Imprimimos el menu
		def imprimirMenu():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			print(30 * "-", "EJERCICIO 4", 30 * "-")
			print("1. Introducir registro manualmente ")
			print("2. Buscar registro ")
			print("3. Exportar registros a fichero CSV ")
			print("4. Importar registros de fichero CSV ")        
			print("5. Imprimir registros del diccionario ")        
			print("0. Salir ")
			print(73 * "-")

		continuar = True
		int_choice = -1

		# Definimos los registros
		registros = {}

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			imprimirMenu()
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-5]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				registro = pedirDatos()
				registros[len(registros)] = registro
			elif opcion == '2':
				buscarRegistros(registros)
			elif opcion == '3':
				exportarRegistros(registros)
			elif opcion == '4':
				registros = importarRegistros()
			elif opcion == '5':
				imprimirRegistros(registros)
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mensaje de error si no es una opción correcta
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]