from sge05.ejercicio1.usuarios import Usuarios
from sge05.ejercicio2.passwords import Passwords

class GestorUsuarios():
	def __init__(self):
		print(30 * "-", "EJERCICIO 3", 30 * "-")
		
		# Variables de control
		usuarioValido = 1
		passwordValido = False

		while usuarioValido != 0:
			nombreUsuario = input("Introduce un usuario: ")
			usuarioValido = Usuarios().validarUsuario(nombreUsuario)
			if usuarioValido != 0:
				print ("\tERROR-> El usuario debe ser alfanumérico y tener entre 6 y 12 caracteres.")
			else:
				print ("\tOK-> Usuario correcto")

		while not passwordValido:
			passwordUsuario = input("Introduce un password: ")
			passwordValido = Passwords().validarPassword(passwordUsuario)
			if not passwordValido:
				print ("\tERROR-> El password debe tener: mayúsculas, minúsculas, numeros, caracteres especiales, no tener espacios y tener al menos 8 caracteres.")
			else:
				print ("\tOK-> Password correcto")


		# Devolvemos la salida
		return