import csv
import datetime
import random
from sge05.utilidades.utilidades import Utilidades

class GestorClientes():
	# Método de inicio, obtenemos los datos de configuracion
	def __init__(self):
		utilidades = Utilidades()
		self.models = utilidades.getModelos()
		self.db = utilidades.getDatabase()
		self.uid = utilidades.getUID()
		self.password = utilidades.getPassword()

	# Metodo que muestra el menu
	def mostrarMenu(self):
		# Metodo que nos indica si el login existe en la tabla
		def existeLogin(login):
			salida = False

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.users', 'search_read',
				[[['login', '=', login]]],
				{'fields': ['id', 'name']})

			# El usuario existe
			if len(records) != 0:
				salida = True

			return salida

		# Método para crear el login
		def crearLogin(name):
			salida = ""

			# Separamos nombre y apellidos
			componentes = name.split(" ")

			# Si solo nos pasan nombre, duplicamos
			if len(componentes) < 2:
				componentes[1] = componentes[0]

			# Obtenemos el login
			salida = (componentes[0][0] + componentes[1]).upper()

			# Si existe, le añadimos numeros sucesivos hasta que tengamos uno libre.
			contador = 0
			while existeLogin(salida) == True:
				salida = (componentes[0][0] + componentes[1]).upper() + "_" + str(contador)
				contador = contador + 1

			return salida

		# Método para crear el password
		def crearPassword(name):
			salida = ""

			# Obtenemos los minutos y segundos actuales
			minutos = str(datetime.datetime.now().minute)
			segundos = str(datetime.datetime.now().second)
			caracteres = "%$&"

			# Separamos nombre y apellidos
			componentes = name.split(" ")

			# Si solo nos pasan nombre, duplicamos
			if len(componentes) < 2:
				componentes[1] = componentes[0]

			# Si solo nos pasan un apellido, duplicamos el segundo
			if len(componentes) < 3:
				componentes[2] = componentes[1]

			# Comenzamos a crear la cadena
			salida = componentes[0][0] + segundos

			# Ahora el apellido (si no tiene longitud suficiente, metemos --)
			if len(componentes[1]) < 3:
				salida = salida + "--" + minutos
			else:
				salida = salida + componentes[1][1:3] + minutos

			# Ahora el apellido2
			if len(componentes[1]) < 4:
				salida = salida + "-" + random.choice(caracteres)
			else:
				salida = salida + componentes[1][3] + random.choice(caracteres)
						
			
			return salida

		# Método para procesar una fila del CSV
		def procesarFila(row):
			# Devolvemos -1 si hay error, 0 si insertamos, 1 si modificamos
			salida = -1

			# Descomponemos la fila en sus campos
			name, display, street, phone, email, website, city, zip, category = row

			# Comprobamos si existe el usuario
			usuarioExistente = existeUsuario(name)
			# Comprobamos si existe la categoria
			categoriaExistente = obtenerCategoriaPorNombre(category)
			
			# Si no existe el usuario en la tabla...
			if usuarioExistente == False:
				insertarUsuario(name)
				usuarioExistente = existeUsuario(name)
				salida = 0
			else:
				salida = 1

			if obtenerClientePorNombre(name) != False:
				actualizarCliente(row, categoriaExistente)

			return salida

		# Método que inserta un usuario
		def insertarUsuario(name):
			# Creamos el login
			login = crearLogin(name)
			# Creamos el password
			password = crearPassword(name)			

			# Comprobamos que existe
			id = self.models.execute_kw(self.db, self.uid, self.password,
				'res.users', 'create',
				[{
					'name': name,
					'login': login,
					'password': password,
				}])

			return id

		# Método que actualiza un cliente
		def actualizarCliente(datos, categoria):
			# Descomponemos la fila en sus campos
			name, display, street, phone, email, website, city, zip, category = datos
			
			# Obtenemos el cliente
			cliente = obtenerClientePorNombre(name)

			id = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'write',
				[cliente['id'], {
					'name': name,
					'display_name': display,
					'street': street,
					'phone': phone,
					'email': email,
					'website': website,
					'city': city,
					'zip': zip,
					'category_id': [categoria['id']]
				}])
			
			return id

		# Método que actualiza un cliente
		def modificarCliente(id, datos, categoria):
			# Descomponemos la fila en sus campos
			name, display, street, phone, email, website, city, zip, category = datos

			self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'write',
				[id, {
					'name': name,
					'display_name': display,
					'street': street,
					'phone': phone,
					'email': email,
					'website': website,
					'city': city,
					'zip': zip,
					'category_id': [categoria['id']]
				}])

		# Método que comprueba si existe un usuario ya creado
		def existeUsuario(name):
			salida = False

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.users', 'search_read',
				[[['name', '=', name]]],
				{'fields': ['id', 'name']})

			# El usuario existe
			if len(records) != 0:
				salida = records[0]

			return salida

		# Método que comprueba si existe un cliente en base a un nombre
		def obtenerClientePorNombre(name):
			salida = False

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'search_read',
				[[['name', '=', name]]],
				{'fields': ['id', 'name']})

			# El usuario existe
			if len(records) != 0:
				salida = records[0]

			return salida

		# Método que comprueba si existe un cliente en base a un id
		def obtenerClientePorId(id):
			salida = False

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'search_read',
				[[['id', '=', id]]],
				{'fields': ['id', 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id']})

			# El usuario existe
			if len(records) != 0:
				salida = records[0]

			return salida

		# Método para importar los clientes desde el CSV
		def importarClientes():
			# Borramos la pantalla
			Utilidades().borrarPantalla()
			
			# Cabecera
			print("IMPORTAR CLIENTES/PROVEEDORES ", 30 * "-")

			# Inicializamos los registros
			registros = {}

			# Pedimos la ruta del archivo
			#archivo = input("Introduce la ruta del archivo a importar: ")
			archivo = "clientes_in.csv"

			# Comprobamos que el archivo exista
			try:
				reader = csv.reader(open(archivo, 'r'))
				header = next(reader)
				# Si no tiene la longitud correcta...
				if len(header) != 9:
					print("Número de campos incorrectos. Debe tener 'name', 'user_id', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id'")
				# Si la tiene, procesamos
				else:
					# Iniciamos los contadores
					registros_insertados = 0
					registros_modificados = 0
					registros_error = 0

					# Recorremos cada fila
					for row in reader:
						# Si tiene longitud incorrecta
						if len(row) != 9:
							registros_error = registros_error + 1
						# Si es correcta, la procesamos
						else:
							# Procesamos el resultado
							resultado = procesarFila(row)

							# Insertado
							if resultado == 0:
								registros_insertados = registros_insertados + 1
							# Actualizado
							elif resultado == 1:
								registros_modificados = registros_modificados + 1
							# Error
							else:
								registros_error = registros_error + 1
							
					# Mostramos el conteo
					print(str(registros_insertados) + " registros insertados correctamente.")
					print(str(registros_modificados) + " registros modificados correctamente.")
					print(str(registros_error) + " registros con errores.")

			# Si no existe...
			except IOError:
				print("No se pudo acceder al fichero")

			input("Pulsa cualquier tecla para continuar...")

		# Método que genera un listado de clientes
		def listarClientes():
			# Borramos la pantalla
			Utilidades().borrarPantalla()
			
			# Obtenemos los registros
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'search_read', [], 
				{'fields': ['id', 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id']})

			# Los imprimimos
			imprimirRegistros(records)

			input("Pulsa cualquier tecla para continuar...")

		# Obtenemos el id de categoria
		def obtenerCategoriaPorNombre(categoria):

			# Ajustamos C, P o T
			if categoria == "C":
				busqueda = "Cliente"
			elif categoria == "P":
				busqueda = "Proveedor"
			elif categoria == "T":
				busqueda = "Proveedor y Cliente"
			else:
				busqueda = categoria

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner.category', 'search_read',
				[[['name', '=', busqueda]]],
				{'fields': ['id', 'name']})

			# La categoria no existe, 
			if len(records) == 0:
				# Comprobamos que existe
				id = self.models.execute_kw(self.db, self.uid, self.password,
					'res.partner.category', 'create',
					[{
						'name': busqueda,
					}])

				# Una vez insertada, la devolvemos
				salida = obtenerCategoriaPorNombre(categoria)

			# Si que existe, la devolvemos
			else:
				salida = records[0]

			return salida

		# Obtenemos la categoria por id
		def obtenerCategoriaPorId(categoria_id):

			# Comprobamos que existe
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner.category', 'search_read',
				[[['id', '=', categoria_id]]],
				{'fields': ['id', 'name']})

			# La categoria no existe, 
			if len(records) == 0:
				# Devolvemos -
				salida = "-"

			# Si que existe, devolvemos el nombre
			else:
				salida = records[0]['name']

			return salida

		# Método para buscar clientes
		def modificarClientes():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Borramos la pantalla
			Utilidades().borrarPantalla()
			
			# Obtenemos los registros
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'search_read', [], 
				{'fields': ['id', 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id']})

			# Los imprimimos
			imprimirRegistros(records)

			# Separador
			print(80 * "-")

			# Pedimos el id del cliente al usuario:
			idCliente = input("Introduce el ID del cliente a editar: ")

			if idCliente.isnumeric():
				# Obtenemos el cliente existente
				clienteExistente = obtenerClientePorId(idCliente)
				
				# Si existe, modificamos
				if clienteExistente != False:
					
					print("INTRODUCE LOS DATOS A MODIFICAR. Entre corchetes estan los datos actuales, si no quieres cambiar alguno, déjalo en blanco.")
					print()

					# Ahora pedimos los datos
					nombreCliente = input("Introduce el nombre del cliente ["+clienteExistente['name']+"]: ")
					if nombreCliente == "":
						nombreCliente = clienteExistente['name']

					personaContacto = input("Introduce la persona de contacto ["+clienteExistente['display_name']+"]: ")
					if personaContacto == "":
						personaContacto = clienteExistente['display_name']

					direccion = input("Introduce la direccion ["+clienteExistente['street']+"]: ")
					if direccion == "":
						direccion = clienteExistente['street']

					telefono = input("Introduce el teléfono ["+clienteExistente['phone']+"]: ")
					if telefono == "":
						telefono = clienteExistente['phone']

					email = input("Introduce el email ["+clienteExistente['email']+"]: ")
					if email == "":
						email = clienteExistente['email']

					website = input("Introduce el website ["+clienteExistente['website']+"]: ")
					if website == "":
						website = clienteExistente['website']

					localidad = input("Introduce la localidad ["+clienteExistente['city']+"]: ")
					if localidad == "":
						localidad = clienteExistente['city']

					cp = input("Introduce el CP ["+clienteExistente['zip']+"]: ")
					if cp == "":
						cp = clienteExistente['zip']

					if len(clienteExistente['category_id']) != 0:
						categoria = input("Introduce la categoria ["+obtenerCategoriaPorId(clienteExistente['category_id'][0])+"]: ")
						if categoria == "":
							categoria = obtenerCategoriaPorId(clienteExistente['category_id'][0])
					else:
						categoria = input("Introduce la categoria ["+obtenerCategoriaPorId(clienteExistente['category_id'][0])+"]: ")

					modificarCliente(clienteExistente['id'],
						[nombreCliente, personaContacto, direccion, telefono, email, website, localidad, cp, categoria], 
						obtenerCategoriaPorNombre(categoria))

				else:
					print("El ID de cliente introducido no existe.")
			else:
				print("Debes introducir un número de cliente.")

			input("Pulsa cualquier tecla para continuar...")

		# Método para exportar a CSV
		def exportarClientes():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			# Cabecera
			print("EXPORTAR CLIENTES ", 30 * "-")

			# Obtenemos los registros
			records = self.models.execute_kw(self.db, self.uid, self.password,
				'res.partner', 'search_read', [], 
				{'fields': ['id', 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id']})

			# Exportamos datos
			with open('clientes_out.csv', 'w') as file_output:
				w = csv.DictWriter(file_output, ('id', 'name', 'display_name', 'street', 'phone', 'email', 'website', 'city', 'zip', 'category_id'))
				w.writeheader()
				for registro in records: 
					w.writerow(registro)

			print("Productos exportados correctamente en clientes_out.csv")
			input("Pulsa cualquier tecla para continuar...")

		# Método para imprimir los registros
		def imprimirRegistros(registros):
			# Cabecera de la tabla
			print ("{:<10} {:<20} {:<20} {:<20} {:<10} {:<20} {:<20} {:<20} {:<10} {:<20}".format('CODIGO', 'NOMBRE CLIENTE', 'PERSONA CONTACTO', 'DIRECCION', 'TELEFONO', 'EMAIL', 'WEBSITE', 'LOCALIDAD', 'CP', 'TIPO')) 
			
			# Si no hay registros
			if len(registros) == 0:
				print("NO HAY RESULTADOS")
			# Si tenemos, los mostramos
			else:
				# Recorremos y dibujamos
				for registro in registros: 
					# Imprimimos registros
					print ("{:<10} {:<20} {:<20} {:<20} {:<10} {:<20} {:<20} {:<20} {:<10} {:<20}".format(
						str(registro['id'])[0:10].ljust(10), 
						str(registro['name'])[0:20].ljust(20), 
						str(registro['display_name'])[0:20].ljust(20),
						str(registro['street'])[0:20].ljust(20), 
						str(registro['phone'])[0:10].ljust(10),
						str(registro['email'])[0:20].ljust(20),
						str(registro['website'])[0:20].ljust(20),
						str(registro['city'])[0:20].ljust(20),
						str(registro['zip'])[0:10].ljust(10),
						str(registro['category_id'])[0:20].ljust(20)))

		# Imprimimos el menu
		def imprimirMenu():
			# Borramos la pantalla
			Utilidades().borrarPantalla()

			print(30 * "-", "EJERCICIO 6", 30 * "-")
			print("1. Importar clientes")
			print("2. Listar clientes")
			print("3. Modificar cliente")
			print("4. Exportar clientes")
			print("0. Salir ")
			print(73 * "-")

		continuar = True

		# Mientras el usuario no quiera salir, continuamos
		while continuar:
			# Imprimimos el menu
			imprimirMenu()
			
			# Capturamos la opción del usuario
			opcion = input("Selecciona opción [1-4]: ")

			# Hacemos un switch con la opción seleccionada
			if opcion == '1':
				importarClientes()
			elif opcion == '2':
				listarClientes()
			elif opcion == '3':
				modificarClientes()
			elif opcion == '4':
				exportarClientes()
			elif opcion == '0':
				print("Saliendo...")
				continuar = False  # Salimos del bucle
			else:
				# Mostramos error de opcion incorrecta
				print("OPCIÓN ERRÓNEA - Inténtalo de nuevo.")

		return [opcion]