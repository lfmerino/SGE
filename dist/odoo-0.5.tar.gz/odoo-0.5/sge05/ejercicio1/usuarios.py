
class Usuarios():
	def validarUsuario(self, username):
		# Definimos la salida
		output = 0 
		# Cadena más corta que 6 caracteres
		output = 1 if (len(username) < 6) else output
		# Cadena más larga que 12 caracteres
		output = 2 if (len(username) > 12) else output
		# Cadena no alfanumerica
		output = 3 if not(username.isalnum()) else output
		# Devolvemos la salida
		return output