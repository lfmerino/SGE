from setuptools import setup
setup(
    name="odoo",
    version="0.1",
    description="Paquete de pruebas para odoo",
    author="Luis Merino",
    author_email="luisfmerinot@gmail.com",
    url="briandademendoza.es",
    packages=['odoo','odoo.addons','odoo.addons.tarea5'],
    scripts=[]
)